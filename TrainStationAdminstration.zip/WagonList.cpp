#include "WagonList.h"

#include <iostream>

WagonList::~WagonList() { clear(); }

void WagonList::clear()
{
    Wagon* current = front; 
    
    while (current != nullptr)
    {
        Wagon* nextWagon = current->next; 
        delete current;
        current = nextWagon;
    }

    front = nullptr;
    rear = nullptr;
    totalWeight = 0;
}

WagonList::WagonList(WagonList &&other) noexcept
{
    front = other.front;
    rear = other.rear;
    totalWeight = other.totalWeight;

    other.front = nullptr;
    other.rear = nullptr;
    other.totalWeight = 0;
}

WagonList &WagonList::operator=(WagonList &&other) noexcept
{
    if (this == &other)
    {
        return *this; 
    }

    clear();

    front = other.front;
    rear = other.rear;
    totalWeight = other.totalWeight;

    other.front = nullptr;
    other.rear = nullptr;
    other.totalWeight = 0;

    return *this;
}

Wagon *WagonList::findById(int id)
{
    Wagon* current = front; 
    while (current != nullptr)
    {
        if (current->getID() == id)
        {
            return current;
        }
        
        current = current->next;
    }

    return nullptr;
}

void WagonList::addWagonToRear(Wagon *w)
{

    if (isEmpty()) 
    {
        front = w;
        rear = w;
    }

    else 
    {
        rear->next = w; 
        
        w->prev = rear; 
        
        rear = w; 
    }

    totalWeight += w->getWeight();
}

int WagonList::getTotalWeight() const { return totalWeight; }

bool WagonList::isEmpty() const
{
    if (front != nullptr) 
    {
        return false; 
    } 
    else 
    {
        return true;
    }
}

void WagonList::insertSorted(Wagon *wagon)
{

    if (isEmpty()) 
    {
        front = wagon;
        rear = wagon;
        totalWeight += wagon->getWeight(); 
        return; 
    }

    if (wagon->getWeight() >= front->getWeight()) 
    {
        wagon->next = front;    
        front->prev = wagon;    
        front = wagon;          
        totalWeight += wagon->getWeight();
        return; 
    }

    Wagon* current = front; 

    while (current->next != nullptr && current->next->getWeight() >= wagon->getWeight())
    {
        current = current->next;
    }

    Wagon* nextNode = current->next;
    current->next = wagon;
    wagon->prev = current;
    wagon->next = nextNode;

    if (nextNode != nullptr)
    {
        nextNode->prev = wagon;
    }
    else
    {
        rear = wagon;
    }

    totalWeight += wagon->getWeight();
}

void WagonList::appendList(WagonList &&other)
{
   if (other.isEmpty())
    {
        return;
    }

    if (this->isEmpty())
    {
  
        this->front = other.front;
        this->rear = other.rear;
        this->totalWeight = other.totalWeight;
    }

    else 
    {

        if (this->front->getWeight() >= other.front->getWeight())
        {

            this->rear->next = other.front;
            other.front->prev = this->rear;
            this->rear = other.rear; 
        }
        else
        {

            other.rear->next = this->front;
            this->front->prev = other.rear;
            this->front = other.front; 
        }
        
        this->totalWeight += other.totalWeight;
    }

    other.front = nullptr;
    other.rear = nullptr;
    other.totalWeight = 0;
}

Wagon *WagonList::detachById(int id)
{
    Wagon* toRemove = findById(id);

    if (toRemove == nullptr)
    {
        return nullptr; 
    }

    if (toRemove == front && toRemove == rear)
    {
        front = nullptr;
        rear = nullptr;
    }
    else if (toRemove == front)
    {
        front = toRemove->next;
        front->prev = nullptr;
    }
    else if (toRemove == rear)
    {
        rear = toRemove->prev;
        rear->next = nullptr;
    }
    else
    {
        toRemove->prev->next = toRemove->next; 
        toRemove->next->prev = toRemove->prev;
    }

    totalWeight -= toRemove->getWeight();

    std::cout << "Wagon " << toRemove->id << " detached from Wagon List. " << std::endl;

    toRemove->prev = nullptr;
    toRemove->next = nullptr;

    return toRemove;
}


WagonList WagonList::splitAtById(int id)
{
    WagonList newList; 
    Wagon* splitWagon = findById(id);

    if (splitWagon == nullptr)
    {
        return newList; 
    }

    if (splitWagon == front)
    {

        newList.front = this->front;
        newList.rear = this->rear;
        newList.totalWeight = this->totalWeight;

        this->front = nullptr;
        this->rear = nullptr;
        this->totalWeight = 0;
    }

    else
    {
       
        newList.front = splitWagon;
        newList.rear = this->rear; 

        Wagon* newThisRear = splitWagon->prev;
        this->rear = newThisRear;

        newThisRear->next = nullptr; 
        splitWagon->prev = nullptr; 

        int newListWeight = 0;
        Wagon* current = newList.front;
        while (current != nullptr)
        {
            newListWeight += current->getWeight();
            current = current->next;
        }
        
        newList.totalWeight = newListWeight;
        this->totalWeight = this->totalWeight - newListWeight;
    }
    
    return newList; 
}

// Print is already implemented
void WagonList::print() const
{

    std::cout << *this << std::endl;
    return;
}

// << operator is already implemented
std::ostream &operator<<(std::ostream &os, const WagonList &list)
{
    if (list.isEmpty())
        return os;

    Wagon *current = list.front;

    while (current)
    {
        os << "W" << current->getID() << "(" << current->getWeight() << "ton)";
        if (current->getNext())
            os << " - ";
        current = current->getNext();
    }
    return os;
}
