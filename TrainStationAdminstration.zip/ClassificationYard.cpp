#include "ClassificationYard.h"
#include <iostream>

ClassificationYard::ClassificationYard() {}
ClassificationYard::~ClassificationYard() { clear(); }

WagonList &ClassificationYard::getBlockTrain(int destination, int cargoType)
{
    return blockTrains[destination][cargoType];
}

WagonList *ClassificationYard::getBlocksFor(Destination dest)
{
    return blockTrains[static_cast<int>(dest)];
}

// Inserts vagon to the corract place at the yard
void ClassificationYard::insertWagon(Wagon *w)
{
    if (!w)
        return;
    int dest = static_cast<int>(w->getDestination());
    int cargo = static_cast<int>(w->getCargoType());
    blockTrains[dest][cargo].insertSorted(w);
}

// Merges multiple blocks into a train while keeping blocks grouped
Train *ClassificationYard::assembleTrain(Destination dest, const std::string &trainName)
{
    int destIndex;
    switch (dest)
    {
        case Destination::ANKARA:    destIndex = 0; break;
        case Destination::IZMIR:     destIndex = 1; break;
        case Destination::ESKISEHIR: destIndex = 2; break;
        case Destination::ADANA:     destIndex = 3; break;
        case Destination::OTHERS:    destIndex = 4; break;
    }

    WagonList* nonHazardousBlocks[NUM_CARGOTYPES_INT];
    int nonHazardousCount = 0;
    
    WagonList* hazardousBlocks[NUM_CARGOTYPES_INT];
    int hazardousCount = 0;

    for (int j = 0; j < NUM_CARGOTYPES_INT; ++j)
    {
        WagonList& currentList = blockTrains[destIndex][j]; 
        if (!currentList.isEmpty())
        {
            CargoType cargo;
            switch(j)
            {
                case 0: cargo = CargoType::COAL; break;
                case 1: cargo = CargoType::OIL; break;
                case 2: cargo = CargoType::HAZARDOUS; break;
                case 3: cargo = CargoType::LIVESTOCK; break;
                case 4: cargo = CargoType::MAIL; break;
                case 5: cargo = CargoType::OTHER; break;
            }

            if (cargo == CargoType::HAZARDOUS)
            {
                hazardousBlocks[hazardousCount] = &currentList;
                hazardousCount++;
            }
            else 
            {
                nonHazardousBlocks[nonHazardousCount] = &currentList;
                nonHazardousCount++;
            }
        }
    }

    Train* t = new Train(trainName, dest);
    for (int i = 0; i < nonHazardousCount; ++i)
    {
        int heaviestWeight = -1;
        int heaviestIndex = -1; 

        for (int k = 0; k < nonHazardousCount; ++k)
        {
            if (nonHazardousBlocks[k] != nullptr)
            {
                int currentWeight = nonHazardousBlocks[k]->getFront()->getWeight();
                if (currentWeight > heaviestWeight)
                {
                    heaviestWeight = currentWeight;
                    heaviestIndex = k; 
                }
            }
        }

        if (heaviestIndex != -1) 
        {
            WagonList& heaviestBlock = *nonHazardousBlocks[heaviestIndex]; 
            t->appendWagonList(heaviestBlock);
            nonHazardousBlocks[heaviestIndex] = nullptr; 
        }
    }

    if (hazardousCount > 0)
    {
        WagonList* heaviestHazardousBlock = hazardousBlocks[0];
        int heaviestHazardousWeight = heaviestHazardousBlock->getFront()->getWeight();

        for (int i = 1; i < hazardousCount; ++i)
        {
            int currentWeight = hazardousBlocks[i]->getFront()->getWeight();
            if (currentWeight > heaviestHazardousWeight)
            {
                heaviestHazardousWeight = currentWeight;
                heaviestHazardousBlock = hazardousBlocks[i];
            }
        }
        
        Wagon* wagonToTake = heaviestHazardousBlock->getFront();
        if (wagonToTake != nullptr) 
        {
            heaviestHazardousBlock->detachById(wagonToTake->getID());
            t->addWagonToRear(wagonToTake);
        }
    }

    if (t->getTotalWeight() == 0)
    {
        delete t; 
        return nullptr;
    }

    return t;
}

bool ClassificationYard::isEmpty() const
{
    for (int i = 0; i < NUM_CARGOTYPES_INT; ++i)
    {
        for (int j = 0; j < NUM_DESTINATIONS_INT; ++j)
        {
            const WagonList& list = blockTrains[j][i]; 
        
            if (!list.isEmpty())
            {
                return false;
            }
        }
    }

    return true;
}

void ClassificationYard::clear()
{
    for (int i = 0; i < NUM_CARGOTYPES_INT; ++i)
    {
        for (int j = 0; j < NUM_DESTINATIONS_INT; ++j)
        {
            blockTrains[j][i].clear();
        }
    }
}

// Print function is already implemented to keep output uniform
void ClassificationYard::print() const
{
    for (int i = 0; i < static_cast<int>(Destination::NUM_DESTINATIONS); ++i)
    {
        auto dest = destinationToString(static_cast<Destination>(i));
        std::cout << "Destination " << dest << ":\n";
        for (int j = 0; j < static_cast<int>(CargoType::NUM_CARGOTYPES); ++j)
        {
            if (!blockTrains[i][j].isEmpty())
            {
                auto type = cargoTypeToString(static_cast<CargoType>(j));
                std::cout << "  CargoType " << type << ": ";
                blockTrains[i][j].print();
            }
        }
    }
}