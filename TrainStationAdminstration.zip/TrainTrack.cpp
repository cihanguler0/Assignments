#include "TrainTrack.h"
#include <iostream>

bool TrainTrack::autoDispatch = false;

TrainTrack::TrainTrack()
    : firstLocomotive(nullptr),
      lastLocomotive(nullptr),
      destination(Destination::OTHERS),
      totalWeight(0), trainCounter(0)
{
}

TrainTrack::TrainTrack(Destination _dest)
    : firstLocomotive(nullptr),
      lastLocomotive(nullptr),
      destination(_dest),
      totalWeight(0), trainCounter(0)
{
}

TrainTrack::~TrainTrack()
{
    while (!isEmpty())
    {
        Train* trainToDelete = departTrain();
        delete trainToDelete;
    }
}

// Given to you ready
std::string TrainTrack::generateTrainName()
{
    ++trainCounter;
    return "Train_" + destinationToString(destination) + "_" + std::to_string(trainCounter);
}

void TrainTrack::addTrain(Train *train)
{
    train->setNext(nullptr);

    if (isEmpty())
    {
        firstLocomotive = train;
        lastLocomotive = train;
    }
    else
    {
        lastLocomotive->setNext(train);
        lastLocomotive = train;
    }

    totalWeight += train->getTotalWeight();

    while (autoDispatch && totalWeight > AUTO_DISPATCH_LIMIT && !isEmpty())
    {
        Train* departed = departTrain();

        if (departed) 
        {
            std::cout << "Auto-dispatch: departing " << departed->getName() << " to make room.\n";
            delete departed;
        }
    }

}

Train *TrainTrack::departTrain()
{
    Train* removed = nullptr; 
    if (isEmpty())
    {
        return nullptr;
    }
    else if (firstLocomotive == lastLocomotive)
    {
        removed = firstLocomotive;
        firstLocomotive = nullptr;
        lastLocomotive = nullptr;
    }
    else
    {
        removed = firstLocomotive;
        firstLocomotive = removed->nextLocomotive;
    }
    totalWeight -= removed->totalWeight;

    std::cout << "Train " << removed->name << " departed from Track " << destinationToString(this->destination) << "." << std::endl;

    removed->nextLocomotive = nullptr;

    return removed;
}

bool TrainTrack::isEmpty() const
{
    if (firstLocomotive != nullptr)
    {
        return false;
    }
    else
    {
        return true;
    }
}


Train *TrainTrack::findTrain(const std::string &name) const
{
    Train* current = firstLocomotive;
    while (current != nullptr)
    {
        if (current->getName() == name)
        {
            return current;
        }
        
        current = current->getNext();
    }

    return nullptr;
}

// Given to you ready
void TrainTrack::printTrack() const
{

    if (isEmpty())
        return;

    Train *current = firstLocomotive;

    std::cout << "[Track " << static_cast<int>(firstLocomotive->destination) << "] ";
    while (current)
    {
        std::cout << current->getName() << "(" << current->getTotalWeight() << "ton)-" << current->wagons << " -> ";
        current = current->getNext();
    }
    std::cout << std::endl;
    return;
}