#include "Train.h"
#include <iostream>

Train::Train() : name(""), destination(Destination::OTHERS), totalWeight(0), nextLocomotive(nullptr) {}
Train::Train(const std::string &_name, Destination _dest) : name(_name), destination(_dest), totalWeight(0), nextLocomotive(nullptr) {}
Train::~Train() { clear(); }

// This function is given to you ready
void Train::appendWagonList(WagonList &wl)
{
    // Makes appendList use move semantics
    wagons.appendList(std::move(wl));
    totalWeight = wagons.getTotalWeight();
}

// This function is given to you ready
void Train::addWagonToRear(Wagon *w)
{
    wagons.addWagonToRear(w);
    totalWeight = wagons.getTotalWeight();
}

void Train::clear()
{ 
    wagons.clear();
    nextLocomotive = nullptr;
}

// This function is given to you ready
void Train::print() const
{
    std::cout << "Train " << name << " (" << totalWeight << " tons): ";
    std::cout << wagons << std::endl;
}

Train *Train::verifyCouplersAndSplit(int splitCounter)
{
    Wagon* current = wagons.getRear(); 
    int currentWeight = 0;

    while (current != nullptr && current->getPrev() != nullptr)
    {
        currentWeight += current->getWeight();
        Wagon* couplerWagon = current->getPrev();

        if (currentWeight > couplerWagon->getMaxCouplerLoad())
        {
            int splitId = current->getID();
            std::cout << "Train " << name << " split due to coupler overload before Wagon " << splitId << std::endl;
            WagonList newWagonList = wagons.splitAtById(splitId);
            this->totalWeight = wagons.getTotalWeight();

            std::string newName = this->name + "_split_" + std::to_string(splitCounter);
            Train* newTrain = new Train(newName, this->destination);
            newTrain->appendWagonList(newWagonList);
            std::cout << newTrain->wagons << std::endl;

            return newTrain;
        }

        current = current->getPrev();
    }

    return nullptr;
}