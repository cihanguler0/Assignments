#include "RailMarshal.h"
#include <iostream>
#include <sstream>
#include <algorithm>

RailMarshal::RailMarshal()
{
    for (int i = 0; i < NUM_DESTINATIONS_INT; ++i)
    {
  
        switch (i)
        {
            case 0: 
                departureYard[i] = TrainTrack(Destination::ANKARA);
                break;
                
            case 1: 
                departureYard[i] = TrainTrack(Destination::IZMIR);
                break;
                
            case 2: 
                departureYard[i] = TrainTrack(Destination::ESKISEHIR);
                break;
                
            case 3: 
                departureYard[i] = TrainTrack(Destination::ADANA);
                break;
                
            case 4: 
                departureYard[i] = TrainTrack(Destination::OTHERS);
                break;
        }
    }
}

RailMarshal::~RailMarshal()
{

}

// Getter (ready)
ClassificationYard &RailMarshal::getClassificationYard()
{
    return classificationYard;
}

// Getter (ready)
TrainTrack &RailMarshal::getDepartureYard(Destination dest)
{
    int idx = static_cast<int>(dest);
    return departureYard[idx];
}

void RailMarshal::processCommand(const std::string &line)
{
    std::stringstream ss(line);
    std::string command; 
    ss >> command; 

    if (command == "ADD_WAGON")
    {
        int id, weight, maxLoad;
        std::string cargoStr, destStr;

        if (ss >> id >> cargoStr >> destStr >> weight >> maxLoad)
        {
            CargoType cargo = parseCargo(cargoStr);
            Destination dest = parseDestination(destStr);
            Wagon* w = new Wagon(id, cargo, dest, weight, maxLoad);
            classificationYard.insertWagon(w); 
            std::cout << "Wagon " << *w << " added to yard." << std::endl;
        }
        else
        {
            std::cout << "Error: Invalid ADD_WAGON parameters.\n";
        }
    }

    else if (command == "REMOVE_WAGON")
    {
        int id;
        if (ss >> id)
        {
            Wagon* w = nullptr;
            for (int i = 0; i < NUM_DESTINATIONS_INT && w == nullptr; ++i)
            {
                for (int j = 0; j < NUM_CARGOTYPES_INT && w == nullptr; ++j)
                {
                    WagonList& list = classificationYard.getBlockTrain(i, j);
                    w = list.detachById(id);
                }
            }

            if (w != nullptr)
            {
                std::cout << "Wagon " << id << " removed." << std::endl;
                delete w;
            }
            else
            {
                std::cout << "Error: Wagon " << id << " not found." << std::endl;
            }
        }
        else
        {
            std::cout << "Error: Invalid REMOVE_WAGON parameters.\n";
        }
    }

    else if (command == "ASSEMBLE_TRAIN")
    {
        std::string destStr;
        if (ss >> destStr)
        {
            Destination dest = parseDestination(destStr);
            TrainTrack& track = getDepartureYard(dest);
            std::string trainName = track.generateTrainName(); 
            Train* t = classificationYard.assembleTrain(dest, trainName);

            if (t == nullptr) 
            {
                std::cout << "No wagons to assemble for " << destStr << std::endl;
            }
            else
            {
                int splitCounter = 1;
                Train* splitTrain = t->verifyCouplersAndSplit(splitCounter);

                while (splitTrain != nullptr)
                {
                    track.addTrain(splitTrain); 
                    std::cout << "Train " << splitTrain->getName() << " assembled after split with "
                    << splitTrain->getWagons() << " wagons." << std::endl;
                    splitCounter++;
                    splitTrain = t->verifyCouplersAndSplit(splitCounter);
                }

                track.addTrain(t);
                std::cout << "Train " << t->getName() << " assembled with " << t->getWagons() << " wagons." << std::endl;
            }
        }
        else
        {
            std::cout << "Error: Invalid ASSEMBLE_TRAIN parameters.\n";
        }
    }

    else if (command == "DISPATCH_TRAIN")
    {
        std::string destStr;
        if (ss >> destStr)
        {
            Destination dest = parseDestination(destStr);
            TrainTrack& track = getDepartureYard(dest);

            if (track.isEmpty())
            {
                std::cout << "Error: No trains to dispatch from track " << destStr << ".\n";
            }
            else
            {
                dispatchFromTrack(dest);
            }
        }
        else
        {
            std::cout << "Error: Invalid DISPATCH parameters.\n";
        }
    }

    else if (command == "PRINT_YARD")
    {
        std::cout << "--- classification Yard ---\n";
        classificationYard.print();
    }

    else if (command == "PRINT_TRACK")
    {
        std::string destStr;
        if (ss >> destStr)
        {
            Destination dest = parseDestination(destStr);
            TrainTrack& track = getDepartureYard(dest);
            track.printTrack(); 
        }
        else
        {
            std::cout << "Error: Invalid PRINT_TRACK parameters.\n";
        }
    }

    else if (command == "AUTO_DISPATCH")
    {
        std::string mode;
        if (ss >> mode)
        {
            if (mode == "ON")
            {
                TrainTrack::autoDispatch = true; 
                std::cout << "Auto dispatch enabled\n";
            }
            else if (mode == "OFF")
            {
                TrainTrack::autoDispatch = false;
                std::cout << "Auto dispatch disabled\n";
            }
            else
            {
                std::cout << "Error: Invalid AUTO_DISPATCH parameters.\n";
            }
        }
        else
        {
            std::cout << "Error: Invalid AUTO_DISPATCH parameters.\n";
        }
    }

    else if (command == "CLEAR")
    {
        classificationYard.clear();
        
        for (int i=0; i < NUM_DESTINATIONS_INT; i++)
        {
            TrainTrack& track = departureYard[i];

            while (!track.isEmpty())
            {
                Train* trainToDelete = track.departTrain();
                
                delete trainToDelete;
            }
        }

        std::cout << "System cleared.\n";
    }

    else
    {
        std::cout << "Error: Unknown command '" << command << "'" << std::endl;
    }
}

void RailMarshal::dispatchFromTrack(Destination track)
{
    TrainTrack& relevantTrack = getDepartureYard(track);
    Train* departedTrain = relevantTrack.departTrain(); 

    if (departedTrain != nullptr)
    {
        std::cout << "Dispatching " << departedTrain->getName() << " (" << departedTrain->getTotalWeight() << " tons)." << std::endl;
        delete departedTrain;
    }
}

void RailMarshal::printDepartureYard() const
{
    for (int i = 0; i < NUM_DESTINATIONS_INT; ++i)
    {
        std::cout << "Track " << i << " ("
                  << destinationToString(static_cast<Destination>(i)) << "):\n";
        departureYard[i].printTrack();
    }
}

// Debug helper functions
void RailMarshal::printStatus() const
{
    std::cout << "--- classification Yard ---\n";
    classificationYard.print();

    std::cout << "--- Departure Yard ---\n";
    for (int i = 0; i < static_cast<int>(Destination::NUM_DESTINATIONS); ++i)
    {
        departureYard[i].printTrack();
    }
}
