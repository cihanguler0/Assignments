import java.io.*;
import java.util.List;

//Main Class for our zoo

public class Main {
    private static PrintWriter outputWriter;

    // Below, there are our arguments.

    public static void main(String[] args) {
        String animalsFile = args[0];
        String peopleFile = args[1];
        String foodFile = args[2];
        String commandFile = args[3];
        String outputFile = args[4];

        List<Animals> animals = null;
        List<People> people = null;
        List<Food> food = null;

        //Below try part, our codes prints initializing parts of the output.

        try {
            outputWriter = new PrintWriter(new FileWriter(outputFile));

            animals = Animals.readTxt(animalsFile);
            people = People.readTxt(peopleFile);
            food = Food.readTxt(foodFile);

            outputWriter.println("***********************************");
            outputWriter.println("***Initializing Animal information***");
            for (Animals animal : animals) {
                outputWriter.println("Added new " + animal.getType() + " with name " + animal.getName() + " aged " + animal.getAge() + ".");
            }
            outputWriter.println("***********************************");
            outputWriter.println("***Initializing Visitor and Personnel information***");
            for (People person : people) {
                outputWriter.println("Added new " + person.getType() + " with id " + person.getId() + " and name " + person.getName() + ".");
            }
            outputWriter.println("***********************************");
            outputWriter.println("***Initializing Food Stock***");
            for (Food f : food)
                outputWriter.println("There are " + f.getFormattedAmount() + " kg of " + f.getName() + " in stock");

            readCommands(commandFile, animals, people, food);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (outputWriter != null) {
                outputWriter.close();
            }
        }
    }

    public static void readCommands(String fileName, List<Animals> animals, List<People> people, List<Food> food) {
            try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
                String command;
                while ((command = br.readLine()) != null) {
                    outputWriter.println("***********************************");
                    outputWriter.println("***Processing new Command***");
                    String[] parts = command.split(",");
                    processCommand(parts, animals, people, food);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
    }

    // This part precess our commands like list, feed or visit.

        public static void processCommand(String[] parts, List<Animals> animals, List<People> people, List<Food> food) {
            String command = parts[0].trim();

            if (command.equals("List Food Stock")) {
                outputWriter.println("Listing available Food Stock:");
                for (int i = food.size() - 1; i >= 0; i--) {
                    Food f = food.get(i);
                    outputWriter.println(f.getName() + ": " + f.getFormattedAmount() + " kgs");
                }
            } else if (command.equals("Animal Visitation")) {
                try {
                    String personId = parts[1].trim();
                    String animalName = parts[2].trim();

                    People foundPerson = personFinder(people, personId);
                    Animals foundAnimal = animalFinder(animals, animalName);

                    if (foundPerson == null && foundAnimal == null) {
                        throw new Exception("Error: There are no animals with the name" + animalName + " and " + "there are no people with the id" + personId);
                    } else if (foundPerson == null) {
                        throw new Exception("Error: There are no visitors or personnel with the id " + personId);
                    } else if (foundAnimal == null) {
                        throw new Exception("Error: There are no animals with the name " + animalName);
                    }

                    String output = foundPerson.visit(foundAnimal);
                    outputWriter.println(output);
                } catch (Exception e) {
                    outputWriter.println(e.getMessage());
                }
            }
            else if (command.equals("Feed Animal")) {
                try {
                    String personId = parts[1].trim();
                    String animalName = parts[2].trim();
                    int times = Integer.parseInt(parts[3].trim());

                    People foundPerson = personFinder(people, personId);
                    Animals foundAnimal = animalFinder(animals, animalName);

                    if (foundPerson == null && foundAnimal == null) {
                        throw new Exception("Error: There are no animals with the name" + animalName + " and " + "there are no people with the id" + personId);
                    } else if (foundPerson == null) {
                        throw new Exception("Error: There are no visitors or personnel with the id " + personId);
                    } else if (foundAnimal == null) {
                        throw new Exception("Error: There are no animals with the name " + animalName);
                    }

                    String output = foundPerson.feed(foundAnimal, food, times);
                    outputWriter.println(output);

                } catch (Exception e) {
                    outputWriter.println("Error: " + e.getMessage());
                }
            }
        }

    // This two functions for achieving other infos about our animals our people by their id or name from inputs.

    private static Animals animalFinder(List<Animals> animals, String name) {
        for (Animals animal : animals) {
            if (animal.getName().equals(name)) {
                return animal;
            }
        }
        return null;
    }

    private static People personFinder(List<People> people, String id) {
            for (People person : people) {
            if (person.getId().equals(id)) {
                return person;
            }
        }
        return null;
    }
}
