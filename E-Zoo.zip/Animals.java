import java.io.*;
import java.util.ArrayList;
import java.util.List;

//Base class of animals

abstract class Animals {   // In this part you can see our variables.
    private String type;
    private String name;
    private int age;
    private double mealSize;

    // Constructor Part

    public Animals(String type, String name, int age, double mealSize) {
        this.type = type;
        this.name = name;
        this.age = age;
        this.mealSize = mealSize;
    }

    // Getters for our variables.

    public String getType() {
        return type;
    }
    public String getName() {
        return name;
    }
    public int getAge() {
        return age;
    }
    public double getMealSize() {
        return mealSize;
    }

    public static List<Animals> readTxt(String input) {
        List<Animals> animalList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(input))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String name = parts[1];

                boolean nameExists = false;
                for (Animals a : animalList) {
                    if (a.getName().equals(name)) {
                        nameExists = true;
                        break;
                    }
                }

                if (nameExists) {
                    System.out.println("Error; " + name + " already exists");
                    continue;
                }

                if (parts[0].equals("Lion")) {
                    Lions lion = new Lions(parts[0], parts[1], Integer.parseInt(parts[2]));
                    animalList.add(lion);
                } else if (parts[0].equals("Elephant")) {
                    Elephants elephant = new Elephants(parts[0], parts[1], Integer.parseInt(parts[2]));
                    animalList.add(elephant);
                } else if (parts[0].equals("Penguin")) {
                    Penguins penguin = new Penguins(parts[0], parts[1], Integer.parseInt(parts[2]));
                    animalList.add(penguin);
                } else if (parts[0].equals("Chimpanzee")) {
                    Chimpanzees chimpanzee = new Chimpanzees(parts[0], parts[1], Integer.parseInt(parts[2]));
                    animalList.add(chimpanzee);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return animalList;
    }

    //This method allows us to calculate meal sizes of animals using their age.

    public static class calculateMealSize {
        public static double calculate(String animalType, int age) {
            switch (animalType) {
                case "Lion":
                    return ((age - 5) * 0.05) + 5;
                case "Elephant":
                    return ((age - 20) * 0.015) + 10;
                case "Penguin":
                    return ((age - 4) * 0.04) + 3;
                case "Chimpanzee":
                    return ((age - 10) * 0.025) + 6;
                default:
                    return 0.0;
            }
        }
    }
}

class Lions extends Animals {   //Sub-Class lions part
   public Lions(String type, String name, int age) {
       super(type, name, age, calculateMealSize.calculate(type, age));
   }
}

class Elephants extends Animals {   //Sub-Class elephants parts
    public Elephants(String type, String name, int age) {
        super(type, name, age, calculateMealSize.calculate(type, age));
    }
}

class Penguins extends Animals {   //Sub-Class penguins part
    public Penguins(String type, String name, int age) {
        super(type, name, age, calculateMealSize.calculate(type, age));
    }
}

class Chimpanzees extends Animals {   //Sub-Class chimpanzees part
    public Chimpanzees(String type, String name, int age) {
        super(type, name, age, calculateMealSize.calculate(type, age));
    }
}


