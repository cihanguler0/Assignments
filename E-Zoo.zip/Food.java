import java.io.*;
import java.util.ArrayList;
import java.util.List;

//Base Class of food

abstract class Food {
    String name;
    float amount;

    // Constructor Part

    public Food(String name, float amount) {
        this.name = name;
        this.amount = amount;
    }

    // Getters for our variables.

    public String getName() {
        return name;
    }
    public float getAmount() {
        return amount;
    }

    //This one for the format of results for printing output.

    public String getFormattedAmount() {
        float truncated = (float) (Math.floor(amount * 1000) / 1000.0);
        return String.format("%.3f", truncated);
    }

    public static List<Food> readTxt(String input) {
        List<Food> fList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(input))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals("Meat")) {
                    Meat m = new Meat(parts[0], Float.parseFloat(parts[1]));
                    fList.add(m);
                } else if (parts[0].equals("Fish")) {
                    Fish f = new Fish(parts[0], Float.parseFloat(parts[1]));
                    fList.add(f);
                } else if (parts[0].equals("Plant")) {
                    Plant p = new Plant(parts[0], Float.parseFloat(parts[1]));
                    fList.add(p);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fList;
    }
}

class Meat extends Food {   //Dub-Class meat part
    public Meat(String name, float amount) {
        super(name, amount);
    }
}

class Fish extends Food {   //Sub-Class Fish part
    public Fish(String name, float amount) {
        super(name, amount);
    }
}

class Plant extends Food {   //Sub-Class plant part
    public Plant(String name, float amount) {
        super(name, amount);
    }
}