import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.text.DecimalFormat;

//Base Class of people

abstract class People {
    private String type;
    private String name;
    private String id;

    // Constructor Part

    public People(String type, String name, String id) {
        this.type = type;
        this.name = name;
        this.id = id;
    }

    // Getters for our variables.

    public String getType() {
        return type;
    }
    public String getName() {
        return name;
    }
    public String getId() {
        return id;
    }

    public static List<People> readTxt(String input) {
        List<People> personList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(input))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String id = parts[2];

                boolean idExists = false;
                for (People p : personList) {
                    if (p.getId().equals(id)) {
                        idExists = true;
                        break;
                    }
                }

                if (idExists) {
                    System.out.println("Error: " + id + " already exists");
                    continue;
                }
                if (parts[0].equals("Visitor")) {
                    Visitors visitor = new Visitors(parts[0], parts[1], parts[2]);
                    personList.add(visitor);
                } else if (parts[0].equals("Personnel")) {
                    Personnels personnel = new Personnels(parts[0], parts[1], parts[2]);
                    personList.add(personnel);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return personList;
    }

    //Polymorphism used in this part.

    public abstract String visit(Animals animal);

    public abstract String feed(Animals animal, List<Food> foodList, int times);
}

class Visitors extends People {   //Sub-Class visitors part. Fed and visit commands override.
    public Visitors(String type, String name, String id) {
        super(type, name, id);
    }

    public String visit(Animals animal) {
        return getName() + " tried to register for a visit to " + animal.getName() + ".\n"
                + getName() + " successfully visited " + animal.getName() + ".";
    }

    public String feed(Animals animal, List<Food> foodList, int times) {
        return getName() + " tried to feed " + animal.getName() + "\n"
                + "Error: Visitors do not have the authority to feed animals.";
    }
}

class Personnels extends People {   //Sub-Class personnels part. Fed and visit commands override.
    public Personnels(String type, String name, String id) {
        super(type, name, id);
    }

    public String visit(Animals animal) {
        String output = getName() + " attempts to clean " + animal.getName() + "'s habitat.\n"
                + getName() + " started cleaning " + animal.getName() + "'s habitat.\n"
                + "Cleaning " + animal.getName() + "'s habitat: ";

        switch (animal.getType()) {
            case "Lion":
                output += "Removing bones and refreshing sand.";
                break;
            case "Elephant":
                output += "Washing the water area.";
                break;
            case "Penguin":
                output += "Replenishing ice and scrubbing walls.";
                break;
            case "Chimpanzee":
                output += "Sweeping the enclosure and replacing branches.";
                break;

        }

        return output;
    }

    public String feed(Animals animal, List<Food> foodList, int times) {
        String output = getName() + " attempts to feed " + animal.getName() + ".\n";

        try {
            String animalType = animal.getType();
            double requiredAmount = animal.getMealSize() * times;

            String foodNeeded = "";
            Food match = null;
            Food second = null;

            switch (animalType) {
                case "Lion":
                    foodNeeded = "Meat";
                    break;
                case "Elephant":
                    foodNeeded = "Plant";
                    break;
                case "Penguin":
                    foodNeeded = "Fish";
                    break;

                // You can see chimpanzee's part is a little bit longer because it eats 2 type of ingredients.

                case "Chimpanzee":
                    for (Food f : foodList) {
                        if (f.getName().equals("Meat")) {
                            match = f;
                        } else if (f.getName().equals("Plant")) {
                            second = f;
                        }
                    }

                    double halfAmount = requiredAmount / 2.0;
                    DecimalFormat df = new DecimalFormat("0.000");
                    String halfAmountFormatted = df.format(halfAmount);

                    boolean meatEnough = match != null && match.getAmount() >= halfAmount;
                    boolean plantEnough = second != null && second.getAmount() >= halfAmount;

                    if (meatEnough && plantEnough) {
                        match.amount -= halfAmount;
                        second.amount -= halfAmount;
                        output += animal.getName() + " has been given " + halfAmountFormatted + " kgs of meat and " + halfAmountFormatted + " kgs of leaves";
                    } else {
                        output += "Error: Not enough ";
                        if (!meatEnough && !plantEnough) {
                            output += "Meat and Plant ";
                        } else if (!meatEnough) {
                            output += "Meat";
                        } else {
                            output += "Plant";
                        }
                    }
                    return output;

                default:
                    break;
            }

            for (Food f : foodList) {
                if (f.getName().equals(foodNeeded)) {
                    match = f;
                    break;
                }
            }

            DecimalFormat df = new DecimalFormat("0.000");
            String requiredAmountFormatted = df.format(requiredAmount);

            if (match.getAmount() >= requiredAmount) {
                match.amount -= requiredAmount;
                switch (animalType) {
                    case "Lion":
                        output += animal.getName() + " has been given " + requiredAmountFormatted + " kgs of meat";
                        break;
                    case "Elephant":
                        output += animal.getName() + " has been given " + requiredAmountFormatted + " kgs assorted fruits and hay";
                        break;
                    case "Penguin":
                        output += animal.getName() + " has been given " + requiredAmountFormatted + " kgs of various kinds of fish";
                        break;
                }
            } else {
                output += "Error: Not enough " + foodNeeded;
            }

            return output;

        } catch (Exception e) {
            return "Error while trying to feed the animal: " + e.getMessage();
        }
    }
}