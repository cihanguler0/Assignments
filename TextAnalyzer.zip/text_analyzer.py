import locale
from sys import argv
locale.setlocale(locale.LC_ALL, 'en_US')

def word_counter():   #Function for counting words.
   f_in = (open(argv[1], 'r'))
   words = f_in.read()
   f_in.close()
   words = words.split()   # Splitting text by spaces, so it can count the words.
   words = len(words)
   f_out = (open(argv[2], 'w'))
   f_out.write("Statistics about " + "{:7}".format(argv[1])+":"+"\n")
   f_out.write("{:24}".format("#Words") + ": " + str(words) + "\n")
   f_out.close()

def sentence_counter():   # Function for counting sentences.
   import re   # Imported re, so with the .split command, I can choose more keys.
   f_in = (open(argv[1], 'r'))
   sentences = f_in.read()
   f_in.close()
   sentences = re.split(r'[\.\.\.|!?\.]+', sentences)   #Splitting the text by "..." "!" "?" and ".".
   sentences.pop()   # Deleting last thing in the list, because it creates an extra space character.
   sentences = len(sentences)
   f_out = (open(argv[2], 'a'))
   f_out.write("{:24}".format("#Sentences")+ ": "+ str(sentences)+"\n")
   f_out.close()

def average_number_of_words():   #Function for counting average number of words.
   f_in = (open(argv[1], 'r'))   #Same of the word_counter function.
   words = f_in.read()
   f_in.close()
   words = words.split()
   words = len(words)
   import re   #Same of the sentence_counter function.
   f_in = (open(argv[1], 'r'))
   sentences = f_in.read()
   f_in.close()
   sentences = re.split(r'[\.\.\.|!?\.]+', sentences)
   sentences.pop()
   sentences = len(sentences)
   average = words / sentences   #Dividing words to the sentences to find average.
   f_out = (open(argv[2], 'a'))
   f_out.write("{:24}".format("#Words/#Sentences")+ ": "+ "{:.2f}".format(float(average))+"\n")
   f_out.close()

def character_counter():   #Function for character counting.
   f_in = (open(argv[1], 'r'))
   character = f_in.read()
   f_in.close()
   f_out = (open(argv[2], 'a'))
   f_out.write("{:24}".format("#Characters")+ ": "+ str(len(character))+"\n")
   f_out.close()

def character_counter_but_no_punctuation():   #Function for character counting but no punctuations.
   f_in = (open(argv[1], 'r'))
   counter = f_in.read()
   f_in.close()
   counter = counter.replace("' "," ")   #Deleting the apostrophes at the end of the words.
   punctuations = [" ", "\n", ".", ",", "!", "?", ":", ";", "(", ")"]   #Possible punctuations that may appear on the text.
   for c in punctuations:   #For loop so every punctuation in the text will be deleted.
      counter = counter.replace(c,"")
   f_out = (open(argv[2], 'a'))
   f_out.write("{:24}".format("#Characters (Just Words)")+ ": "+ str(len(counter))+"\n")
   f_out.close()

def shortest_word_finder():   #Functuation for finding shortest word(s) in the text.
    f_in = (open(argv[1], 'r'))
    shortest = f_in.read()
    f_in.close()

    shortest = shortest.replace("' ", " ")    #This and next four line for cleaning text from punctuations because they can change the result.
    shortest = shortest.replace("\n", " ")
    punctuations = [".", ",", "!", "?", ":", ";", "(", ")"]
    for s in punctuations:
       shortest = shortest.replace(s, "")

    shortest = shortest.split(" ")   # Splitting text by using spaces, so it creates a new list just by words' itself
    a = 0
    while a<len(shortest)-1:   #While loop, so it can sort the words in the text by their length. We will use this later.
       first_word= len(shortest[a])
       second_word = len(shortest[a+1])
       if first_word <= second_word:
          a +=1
       else:
          shortest[a], shortest[a+1] = shortest[a+1], shortest[a]
          a = 0

    shortest_words = []   #Creating a new list the change upper cases to lower cases
    for s in shortest:   #For loop, so every upper case character will be lowered.
       shortest_words.append(s.lower())
    freq = {}   #Creating a new dictionary to storage frequencies of words
    for f in shortest_words:   #For loop so every character's frequency will be counted.
       if f in freq:   #This line adds one to value of frequency if it's already encountered.
          freq[f] += 1
       else:   #This line equals 1 to value of frequency if it's first encounter.
          freq[f] = 1
    sorted_freq = dict(sorted(freq.items(), key=lambda x: (-x[1], x[0])))   #Sorting frequencies firstly by their larger value, if there's equality, by alphabetical.

    f_in = (open(argv[1], 'r'))
    words = f_in.read()   #Same of the word_counter function. We will divide frequencies to this to make our result required format.
    f_in.close()
    words = words.split()
    words = len(words)

    length = len(shortest[0])   #Describing length as the same length as first character of the list. That's why we sorted our list in the first place.
    list_of_shortest = []   #Creating a new list for to add shortest(s).
    for s in sorted_freq:   #For loop so every character will be checked
        while len(s) == length:   #While loop so every character that equals to our selected length will be added to the list.
            list_of_shortest.append(s)
            for sw in shortest_words:   #For loop, because after adding we will check the text to remove same characters; otherwise they would be added multiple times.
                if sw == sw:
                    shortest_words.remove(sw)
            break
    f_out = (open(argv[2], 'a'))
    checkpoint = False   #Creating a checkpoint because there'll be line in the loop that we don't want to execute more than once.
    for s in list_of_shortest:   #For loop so every character in list_of_shortest will be checked; to learn there is just one character or more.
        if len(list_of_shortest) == 1:   #If there is just one character printing the casual format.
            f_out.write("{:24}".format("The Shortest Word ")+ ": "+ "{:24}".format(s)+" ("+"{:.4f}".format(sorted_freq[s] / words)+")"+"\n")
        else:   #If there is more than one character they will be printed in different lines
            if not checkpoint:
              f_out.write("{:24}".format("The Shortest Words")+":"+"\n")
              checkpoint = True   #Making checkpoint "True" because we want to print "The Shortest Word:" part just once
            f_out.write("{:24}".format(s)+" ("+"{:.4f}".format(sorted_freq[s] / words)+")"+"\n")
    f_out.close()

def longest_word_finder():   #Functuation for finding longest word(s) in the text.
    f_in = (open(argv[1], 'r'))
    longest = f_in.read()
    f_in.close()

    longest = longest.replace("' "," ")   #This and next four line for cleaning text from punctuations because they can change the result.
    longest = longest.replace("\n", " ")
    punctuations = [".", ",", "!", "?", ":", ";", "(", ")"]
    for l in punctuations:
        longest = longest.replace(l,"")

    longest = longest.split(" ")   # Splitting text by using spaces, so it creates a new list just by words' itself
    a = 0
    while a<len(longest)-1:   #While loop, so it can sort the words in the text by their length. We will use this later.
        first_word= len(longest[a])
        second_word = len(longest[a+1])
        if first_word <= second_word:
            a +=1
        else:
            longest[a], longest[a+1] = longest[a+1], longest[a]
            a = 0

    longest_words = []   #Creating a new list the change upper cases to lower cases
    for l in longest:   #For loop, so every upper case character will be lowered.
        longest_words.append(l.lower())
    freq = {}   #Creating a new dictionary to storage frequencies of words
    for f in longest_words:   #For loop so every character's frequency will be counted.
        if f in freq:    #This line adds one to value of frequency if it's already encountered.
         freq[f] += 1
        else:   #This line equals 1 to value of frequency if it's first encounter.
         freq[f] = 1
    sorted_freq = dict(sorted(freq.items(), key=lambda x: (-x[1], x[0])))   #Sorting frequencies firstly by their larger value, if there's equality, by alphabetical.

    f_in = (open(argv[1], 'r'))
    words = f_in.read()   #Same of the word_counter function. We will divide frequencies to this to make our result required format.
    f_in.close()
    words = words.split()
    words = len(words)

    length = len(longest_words[a])   #Describing length as the same length as last character of the list. That's why we sorted our list in the first place.
    list_of_longest = []   #Creating a new list for to add longest(s).
    for l in sorted_freq:   #For loop so every character will be checked
        while len(l) == length:   #While loop so every character that equals to our selected length will be added to the list.
             list_of_longest.append(l)
             for lw in longest_words:   #For loop, because after adding we will check the text to remove same characters; otherwise they would be added multiple times.
                 if lw == lw:
                     longest_words.remove(lw)
             break
    f_out = (open(argv[2], 'a'))
    checkpoint = False   #Creating a checkpoint because there'll be line in the loop that we don't want to execute more than once.
    for l in list_of_longest:     #For loop so every character in list_of_longest will be checked; to learn there is just one character or more.
        if len(list_of_longest) == 1:   #If there is just one character printing the casual format.
            f_out.write("{:24}".format("The Longest Word")+": "+"{:24}".format(l)+" ("+"{:.4f}".format(sorted_freq[l] / words)+")"+"\n")
        else:   #If there is more than one character they will be printed in different lines
            if not checkpoint:
                f_out.write("{:24}".format("The Longest Words")+":"+"\n")
                checkpoint = True   #Making checkpoint "True" because we want to print "The Shortest Word:" part just once
            f_out.write("{:24}".format(l)+" ("+"{:.4f}".format(sorted_freq[l] / words)+")"+"\n")
    f_out.close()

def frequency_finder():   #Function for counting frequencies of the words.
    f_in = (open(argv[1], 'r'))
    text = f_in.read()

    text = text.replace("' "," ")   # This part is for cleaning text from punctuations because they can change the result.
    text = text.replace("\n", " ")
    punctuations = [".", ",", "!", "?", ":", ";", "(", ")"]
    for t in punctuations:
        text = text.replace(t,"")

    text = text.split(" ")
    no_capital_text = []   # Changing the upper cases the lower cases
    for t in text:
        no_capital_text.append(t.lower())
    freq = {}   #Creating a dictionary the storage frequencies.
    for f in no_capital_text:
        if f in freq:
            freq[f] += 1
        else:
            freq[f] = 1
    sorted_freq = dict(sorted(freq.items(), key=lambda x: (-x[1], x[0])))

    f_in = (open(argv[1], 'r')) #Same of the word_counter function
    words = f_in.read()
    words = words.split()
    words = len(words)

    f_out = (open(argv[2], 'a'))
    f_out.write("{:24}".format("Words and Frequencies")+ ":"+"\n")
    for sf in sorted_freq:
        f_out.write("{:24}".format(sf)+": "+"{:.4f}".format(sorted_freq[sf]/words)+"\n")

def main():
    word_counter()
    sentence_counter()
    average_number_of_words()
    character_counter()
    character_counter_but_no_punctuation()
    shortest_word_finder()
    longest_word_finder()
    frequency_finder()
    f_out = (open(argv[2], 'r'))
    last_line = f_out.read()
    f_out = open(argv[2], 'w')
    f_out.write(last_line[:-1])
    f_out.close()

if __name__ == '__main__':
    main()
