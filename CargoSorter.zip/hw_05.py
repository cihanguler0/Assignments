import os
# Custom pseudorandom number generator with a random initial seed
class PRNG:
    def __init__(self, seed=None):
        # Use a truly random seed if no seed is provided
        if seed is None:
            seed = int.from_bytes(os.urandom(4), 'big')  # Generate a random 32-bit integer
        self.state = seed

    def randint(self, low, high):
        # Simple linear congruential generator (LCG)
        self.state = (1103515245 * self.state + 12345) % (2**31)
        return low + (self.state % (high - low + 1))

# Generate logistics dataset
def generate_logistics_dataset(num_warehouses=100, max_packages=1000, seed=None):
    """Generates a logistics dataset with a random or specified seed."""
    prng = PRNG(seed)  # Initialize PRNG with the seed or a random one
    data = []
    for i in range(1, num_warehouses + 1):
        warehouse_id = f"WH-{str(i).zfill(3)}"
        priority_level = prng.randint(1, 5)
        package_count = prng.randint(0, max_packages)
        data.append([warehouse_id, priority_level, package_count])
    return data

# Save dataset to a CSV file
def save_to_csv(data, file_name):
    """Saves the dataset to a CSV file."""
    with open(file_name, "w") as file:
        # Write the header
        file.write("Warehouse_ID,Priority_Level,Package_Count\n")
        # Write each row
        for row in data:
            file.write(",".join(map(str, row)) + "\n")


######### YOUR CODE GOES HERE ---  You should define here two_level_sorting and the 3 sorting functions

counter = 0


def reset_counter():    # Function for resetting counter for every step
    global counter
    counter = 0


def error_handling(data):   # This part is for the handling the error situations that you asked for in the script.
    if not data:
        raise ValueError("Input is empty. Please check.")

    if len(data) == 1:
        print("Input contains single element. There is nothing to sort. Please check.")

    for row in data:
        if len(row) != 3:
            raise ValueError(f"Warehouse ID, Priorities or Packages are empty. Please check.")
        try:
            int(row[1])  # Ensure Priority_Level is an integer
            int(row[2])  # Ensure Package_Count is an integer
        except ValueError:
            raise ValueError(f"Priority or Packages are not integers. . Please check.")

    unique_data = list(set(tuple(row) for row in data))
    if len(unique_data) != len(data):
        data[:] = unique_data  # Update input with unique rows

    return data


def two_level_sorting(func, data):
    global counter

    error_handling(data)
    reset_counter()
    priority_sort = func(data, key=1)
    priority_counter = counter

    priority_group = {}   # In here, code groups all the warehouses with the same priority so it can sort them by their second key, packages.
    for data in priority_sort:
        priority_lvl = data[1]
        if priority_lvl not in priority_group:
            priority_group[priority_lvl] = []
        priority_group[priority_lvl].append(data)

    reset_counter()
    sorted_data = []
    for priority, group in priority_group.items():
        sorted_group = func(group, key=2)
        sorted_data.extend(sorted_group)

    package_counter = counter
    return sorted_data, priority_counter, package_counter


def bubble_sort(data, key):   #Bubble sorting part
    global counter
    data = data[:]
    for d in range(len(data) - 1):
        for i in range(len(data) - 1 - d):
            counter += 1
            if data[i][key] > data[i + 1][key]:
                data[i], data[i + 1] = data[i + 1], data[i]
    return data


def merge_sort(data, key):    # Merge sorting part
    global counter
    data = data[:]

    def merge(left, right, key):
        global counter
        new_data = []
        i, j = 0, 0
        while i < len(left) and j < len(right):
            if left[i][key] <= right[j][key]:
                new_data.append(left[i])
                i += 1
            else:
                counter += 1
                new_data.append(right[j])
                j += 1
        new_data.extend(left[i:])
        new_data.extend(right[j:])
        return new_data

    if len(data) <= 1:
        return data

    left = merge_sort(data[:len(data) // 2], key)
    right = merge_sort(data[len(data) // 2:], key)
    return merge(left, right, key)


def quick_sort(data, key):   # Quick sorting part
    global counter
    data = data[:]

    if len(data) <= 1:
        return data

    index = len(data) // 2
    if len(data) // 2 == 0:
       pivot = data[index+1][key]
    else:
       pivot = data[index][key]

    smaller = []
    pivots = []
    larger = []
    for d in data:
        if d[key] < pivot:
            smaller.append(d)
        elif d[key] == pivot:
            pivots.append(d)
        else:
            larger.append(d)
    counter += 1

    return quick_sort(smaller, key) + pivots + quick_sort(larger, key)

######### END OF YOUR CODE #########
#########

def write_output_file(
    bubble_sorted, merge_sorted, quick_sorted,
    bubble_sort_pl_iterations, merge_sort_pl_counter, quick_sort_pl_counter,
    bubble_sort_pc_iterations, merge_sort_pc_counter, quick_sort_pc_counter,
    merge_check, quick_check
):
    """Write sorted results and comparisons to the output file."""
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as file:
        file.write("=== Bubble Sorted Results ===\n")
        # file.write(bubble_sorted.to_string() + "\n\n")
        file.write("Warehouse_ID  Priority_Level  Package_Count\n")
        file.write("-" * 40 + "\n")
        for row in bubble_sorted:
            file.write(f"{row[0]:<12}  {row[1]:<14}  {row[2]:<13}\n")
        file.write("\n")
        file.write("=== Comparison Results ===\n")
        if merge_check:
            file.write("Merge and Bubble sorts are identical.\n")
        else:
            file.write("Merge and Bubble sorts differ.\n")

        if quick_check:
            file.write("Quick and Bubble sorts are identical.\n")
        else:
            file.write("Quick and Bubble sorts differ.\n")

        file.write("\n=== Sort Performance Metrics ===\n")
        file.write(f"Bubble priority sort iteration count: {bubble_sort_pl_iterations}\n")
        file.write(f"Merge priority sort n_of right array is smaller than left: {merge_sort_pl_counter}\n")
        file.write(f"Quick priority sort recursive step count: {quick_sort_pl_counter}\n\n")

        file.write(f"Bubble package count sort iteration count: {bubble_sort_pc_iterations}\n")
        file.write(f"Merge package count n_of right array is smaller than left: {merge_sort_pc_counter}\n")
        file.write(f"Quick package count sort recursive step count: {quick_sort_pc_counter}\n")

    print(f"Results written to {OUTPUT_FILE}")

if __name__ == "__main__":
    # File paths and dataset size
    # Specify paths for input and output files
    INPUT_FILE = "hw05_input.csv"   # Path where the generated dataset will be saved
    OUTPUT_FILE = "hw05_output.txt"  # Path where the sorted results and metrics will be saved
    SIZE = 100  # Number of warehouses in the dataset

    # Generate the dataset
    dataset = generate_logistics_dataset(SIZE, max_packages=100)  # Generate a dataset with SIZE warehouses and max_packages packages

    # Save the generated dataset to the input file
    save_to_csv(dataset, INPUT_FILE)


    ###############################################################################################################
    # Perform sorting and counting operations
    # Sort using Bubble Sort and count iterations for Priority Level (_pl_) and Package Count (_pc_)
    bubble_sorted, bubble_sort_pl_iterations, bubble_sort_pc_iterations = two_level_sorting(bubble_sort, dataset)

    # Sort using Merge Sort and count recursive steps for Priority Level and Package Count
    merge_sorted, merge_sort_pl_counter, merge_sort_pc_counter = two_level_sorting(merge_sort, dataset)

    # Sort using Quick Sort and count recursive steps for Priority Level and Package Count
    quick_sorted, quick_sort_pl_counter, quick_sort_pc_counter = two_level_sorting(quick_sort, dataset)
    ###############################################################################################################


    # Comparisons
    # Check if Merge Sort results match Bubble Sort results
    merge_check = merge_sorted == bubble_sorted

    # Check if Quick Sort results match Bubble Sort results
    quick_check = quick_sorted == bubble_sorted

    # Write results and metrics to the output file
    write_output_file(
        bubble_sorted, merge_sorted, quick_sorted,
        bubble_sort_pl_iterations, merge_sort_pl_counter, quick_sort_pl_counter,
        bubble_sort_pc_iterations, merge_sort_pc_counter, quick_sort_pc_counter,
        merge_check, quick_check
    )


   
