from sys import argv

def create_table(table, command):   #Function for creating table
   commands = command.split()       #In these parts I split my code for to use in different places.
   person_name = commands[1]
   columns = commands[2].split(",")

   table[person_name] = {           #Creating our dictionary
      "columns": columns,
      "person_data": []
   }

   print("#"*22, "CREATE", "#"*25)
   print(f"Table '{person_name}' created with columns: {columns}")
   print("#"*55+"\n")

   return table

def insert(table, command):              #Function for installing                               #Try part for detecting errors
   commands = command.split(" ",2)
   person_name = commands[1]
   data = commands[2].split(",")

   try:
      sql = table[person_name]                 #Making equal sql to table[person_name] for easy usage
      sql["person_data"].append(tuple(data))   #Adding datas of people to our dictionary as tuples
   except KeyError:
      print("#" * 22, "INSERT", "#" * 25)
      print(f"Table {person_name} not found")
      print(f"Inserted into '{person_name}': {tuple(data)}")
      print("#" * 55 + "\n")
      return table

   print("#"*22, "INSERT", "#"*25)
   print(f"Inserted into '{person_name}': {tuple(data)}"+"\n")
   print(f"Table: {person_name}")

   longest = []                        #Part for recognizing the longest words in each column, so spaces are according to them
   for c in sql["columns"]:
      longest.append(len(c))
   for data in sql["person_data"]:
      for a, b in enumerate(data):
         if len(str(b)) > longest[a]:
            longest[a] = len(str(b))

   line1 = "".join("+" + "-"*(l+2) for l in longest)         #Printing the table
   line2 = "".join("| " + c + " "*(l-len(c)+1)for l,c in zip(longest, sql["columns"]))
   print(line1+"+")
   print(line2+"|")
   print(line1+"+")
   for datas in sql["person_data"]:
      line3 = "".join("| " + d + " " * (l - len(d) + 1) for l, d in zip(longest, datas))
      print(line3+"|")

   print(line1+"+")
   print("#" * 55+"\n")

   return table

def select(table, command):                 #Function for selecting
   commands = command.split(" ",4)
   person_name = commands[1]
   info = commands[2].split(",")         #Info is the asked information
   conditions = commands[4].split(",")   #Condition is the information about who will be chosen

   clean_conditions = {}                   #Cleaning conditions as the wanted format in the output
   for c in conditions:
      c = c.strip('{}')
      c_key, c_value = c.split(":")
      c_key = c_key.strip().strip('"')
      c_value = c_value.strip().strip('"') #Making keys and values the condition
      clean_conditions[c_key] = c_value

      '''if person_name not in table:
         print("#" * 22, "SELECT", "#" * 25)
         print(f"Table {person_name} not found")
         print(f"Condition: {clean_conditions}")
         print(f"Select result from '{person_name}': None")
         print("#" * 55 + "\n")
         return table'''

   try:
      sql = table[person_name]
   except KeyError:
      print("#" * 22, "SELECT", "#" * 25)
      print(f"Table {person_name} not found")
      print(f"Condition: {clean_conditions}")
      print(f"Select result from '{person_name}': None")
      print("#" * 55 + "\n")
      return table

   print("#" * 22, "SELECT", "#" * 25)

   try:
      no_column = [col for col in clean_conditions.keys() if col not in sql["columns"]]   #In this part it finds if there is a problem in conditions
      if no_column:
         raise ValueError
   except ValueError:
      print(f"Column {no_column[0]} does not exist")
      print(f"Condition: {clean_conditions}")
      print(f"Select result from '{person_name}': None")
      print("#" * 55 + "\n")
      return table

   try:
      if info != ['*']:                                                                   #If info is "*" we select all the rows
         no_column = [col for col in info if col not in sql["columns"]]                   #In this is part it finds if there is a problem in result part
         if no_column:
            raise ValueError
   except ValueError:
         print(f"Column {no_column[0]} does not exist")
         print(f"Condition: {clean_conditions}")
         print(f"Select result from '{person_name}': None")
         print("#" * 55 + "\n")
         return table

   whole_data = [dict(zip(sql["columns"], people)) for people in sql["person_data"]]   #In here we zip and combine all the columns and datas in a one complete dict
   for condition in conditions:
      all_data = condition.strip('{}').split(':')
      key = all_data[0].strip().strip('"')
      value = all_data[1].strip().strip('"')
      wanted_data = [wd for wd in whole_data if wd.get(key) == value]

   wanted_values = []                                     #In this here we find wanted information in the correct form as the output
   for data in wanted_data:
      if info == ['*']:                                   #If info is "*" we select all the rows
         values = [data[key] for key in sql["columns"]]
      else:
         values = [data[key] for key in info]
      wanted_values.append(values)

   print("Condition:", clean_conditions)

   tuple_wanted_data = [tuple(data) for data in wanted_values]

   print(f"Select result from '{person_name}': {tuple_wanted_data}")
   print("#"*55+"\n")

   return table

def update(table, command):                                                                 #Function for updating
   commands = command.split(" ",2)                                                          # In this part I used a different split method, because splitting by spaces creates problem if there is multiple conditions.
   commands_continues = commands[2].split(" WHERE ")
   commands = commands[:2] + [commands_continues[0], " WHERE ", commands_continues[1]]
   person_name = commands[1]
   new_info = commands[2].split(",")
   conditions = commands[4].split(",")

   clean_conditions = {}
   for c in conditions:
      c = c.strip('{}')
      c_key, c_value = c.split(":")
      c_key = c_key.strip().strip('"')
      c_value = c_value.strip().strip('"')
      clean_conditions[c_key] = c_value

   clean_new_info = {}  # In here we clean the information that we'll update as the output format
   for ni in new_info:
      ni = ni.strip('{}')
      ni_key, ni_value = ni.split(":")
      ni_key = ni_key.strip().strip('"')
      ni_value = ni_value.strip().strip('"')
      clean_new_info[ni_key] = ni_value  # Turning them into a dictionary

   try:
      sql = table[person_name]
   except KeyError:
      print("#" * 22, "UPDATE", "#" * 25)
      print(f"Updated '{person_name}' with {clean_new_info} where {clean_conditions}")
      print(f"Table {person_name} not found")
      print(f"0 rows updated.")
      print("#" * 55 + "\n")
      return table

   try:
      no_column = [col for col in clean_new_info.keys() if col not in sql["columns"]]
      if no_column:
         raise ValueError
   except ValueError:
      print("#" * 22, "UPDATE", "#" * 25)
      print(f"Updated '{person_name}' with {clean_new_info} where {clean_conditions}")
      print(f"Column {no_column[0]} does not exist")
      print(f"0 rows updated." + "\n")
      print(f"Table: {person_name}")

      longest = []
      for c in sql["columns"]:
         longest.append(len(c))
      for data in sql["person_data"]:
         for a, b in enumerate(data):
            if len(str(b)) > longest[a]:
               longest[a] = len(str(b))

      line1 = "".join("+" + "-" * (l + 2) for l in longest)
      line2 = "".join("| " + c + " " * (l - len(c) + 1) for l, c in zip(longest, sql["columns"]))
      print(line1 + "+")
      print(line2 + "|")
      print(line1 + "+")
      for datas in sql["person_data"]:
         line3 = "".join("| " + d + " " * (l - len(d) + 1) for l, d in zip(longest, datas))
         print(line3 + "|")

      print(line1 + "+")
      print("#" * 55 + "\n")
      return table

   try:
      no_column = [col for col in clean_conditions.keys() if col not in sql["columns"]]
      if no_column:
         raise ValueError
   except ValueError:
      print("#" * 22, "UPDATE", "#" * 25)
      print(f"Updated '{person_name}' with {clean_new_info} where {clean_conditions}")
      print(f"Column {no_column[0]} does not exist")
      print(f"0 rows updated." + "\n")
      print(f"Table: {person_name}")

      longest = []
      for c in sql["columns"]:
         longest.append(len(c))
      for data in sql["person_data"]:
         for a, b in enumerate(data):
            if len(str(b)) > longest[a]:
               longest[a] = len(str(b))

      line1 = "".join("+" + "-" * (l + 2) for l in longest)
      line2 = "".join("| " + c + " " * (l - len(c) + 1) for l, c in zip(longest, sql["columns"]))
      print(line1 + "+")
      print(line2 + "|")
      print(line1 + "+")
      for datas in sql["person_data"]:
         line3 = "".join("| " + d + " " * (l - len(d) + 1) for l, d in zip(longest, datas))
         print(line3 + "|")

      print(line1 + "+")
      print("#" * 55 + "\n")
      return table

   print("#" * 22, "UPDATE", "#" * 25)
   print(f"Updated '{person_name}' with {clean_new_info} where {clean_conditions}")

   updated_row = 0  # In this part we calculate how many rows affected from update.
   already_updated_row = set()
   for condition_key, condition_value in clean_conditions.items():
      for data in sql["person_data"]:
         whole_dict = dict(zip(sql["columns"], data))
         if whole_dict.get(condition_key) == condition_value:
            if data not in already_updated_row:
               updated_row += 1
   print(updated_row, "rows updated." + "\n")
   print(f"Table: {person_name}")

   for index, cond in enumerate(sql[
                                   "person_data"]):  # In this part our code goes through each variable together and changes the old ones with updated ones.
      cond_dict = dict(zip(sql["columns"], cond))
      if all(cond_dict.get(key) == value for key, value in clean_conditions.items()):
         updated_cond = list(cond)
         for key, value in clean_new_info.items():
            if key in sql["columns"]:
               updated_cond[sql["columns"].index(key)] = value
         sql["person_data"][index] = tuple(updated_cond)

   longest = []
   for c in sql["columns"]:
      longest.append(len(c))
   for data in sql["person_data"]:
      for a, b in enumerate(data):
         if len(str(b)) > longest[a]:
            longest[a] = len(str(b))

   line1 = "".join("+" + "-" * (l + 2) for l in longest)
   line2 = "".join("| " + c + " " * (l - len(c) + 1) for l, c in zip(longest, sql["columns"]))
   print(line1 + "+")
   print(line2 + "|")
   print(line1 + "+")
   for datas in sql["person_data"]:
      line3 = "".join("| " + d + " " * (l - len(d) + 1) for l, d in zip(longest, datas))
      print(line3 + "|")

   print(line1 + "+")
   print("#" * 55 + "\n")

   return table

def delete(table, command):                   #Function for deleting
   commands = command.split(" ", 3)
   person_name = commands[1]
   conditions = commands[3].split(",")

   clean_conditions = {}
   if conditions == ['*']:
      clean_conditions = {"*": "*"}
   else:
      for c in conditions:
         c = c.strip('{}')
         c_key, c_value = c.split(":")
         c_key = c_key.strip().strip('"')
         c_value = c_value.strip().strip('"')
         if c_value.isdigit():
            c_value = int(c_value)
         clean_conditions[c_key] = c_value

   try:
      sql = table[person_name]
   except KeyError:
      print("#" * 22, "DELETE", "#" * 25)
      print(f"Deleted from '{person_name}' where {clean_conditions}")
      print(f"Table {person_name} not found")
      print(f"0 rows deleted.")
      print("#" * 55 + "\n")
      return table

   try:
      no_column = [col for col in clean_conditions.keys() if col not in sql["columns"]]
      if no_column:
         raise ValueError
   except ValueError:
      print("#" * 22, "DELETE", "#" * 25)
      print(f"Deleted from '{person_name}' where {clean_conditions}")
      print(f"Column {no_column[0]} does not exist")
      print(f"0 rows deleted." + "\n")
      print(f"Table: {person_name}")

      longest = []
      for c in sql["columns"]:
         longest.append(len(c))
      for data in sql["person_data"]:
         for a, b in enumerate(data):
            if len(str(b)) > longest[a]:
               longest[a] = len(str(b))

      line1 = "".join("+" + "-" * (l + 2) for l in longest)
      line2 = "".join("| " + c + " " * (l - len(c) + 1) for l, c in zip(longest, sql["columns"]))
      print(line1 + "+")
      print(line2 + "|")
      print(line1 + "+")
      for datas in sql["person_data"]:
         line3 = "".join("| " + d + " " * (l - len(d) + 1) for l, d in zip(longest, datas))
         print(line3 + "|")

      print(line1 + "+")
      print("#" * 55 + "\n")
      return table

   print("#" * 22, "DELETE", "#" * 25)
   print(f"Deleted from '{person_name}' where {clean_conditions}")

   updated_row = 0
   if clean_conditions == {"*": "*"}:
      updated_row = len(sql["person_data"])
      sql["person_data"] = []
   else:
      new_person_data = []
      for data in sql["person_data"]:
         whole_dict = dict(zip(sql["columns"], data))
         if all(
                 str(whole_dict.get(condition_key)) == str(condition_value)
                 for condition_key, condition_value in clean_conditions.items()
         ):
            updated_row += 1
         else:
            new_person_data.append(data)
      sql["person_data"] = new_person_data
   print(updated_row, "rows deleted." + "\n")
   print(f"Table: {person_name}")

   sql["person_data"] = [
      tuple(data) for data in sql["person_data"]
      if not all(str(data[sql["columns"].index(key)]) == str(value) for key, value in clean_conditions.items())
   ]

   longest = []
   for c in sql["columns"]:
      longest.append(len(c))
   for data in sql["person_data"]:
      for a, b in enumerate(data):
         if len(str(b)) > longest[a]:
            longest[a] = len(str(b))

   line1 = "".join("+" + "-" * (l + 2) for l in longest)
   line2 = "".join("| " + c + " " * (l - len(c) + 1) for l, c in zip(longest, sql["columns"]))
   print(line1 + "+")
   print(line2 + "|")
   print(line1 + "+")
   for datas in sql["person_data"]:
      line3 = "".join("| " + d + " " * (l - len(d) + 1) for l, d in zip(longest, datas))
      print(line3 + "|")

   print(line1 + "+")
   print("#" * 55 + "\n")

   return table

def join(table, command):                                             #Function for joining
   commands = command.split(" ")
   table_names = commands[1].split(",")
   selected_column = commands[3]

   print("#" * 23, "JOIN", "#" * 26)
   print(f"Join tables {table_names[0]} and {table_names[1]}")

   try:
      for table_name in table_names:
         if table_name not in table:
            raise KeyError
   except KeyError:
         print(f"Table {table_name} does not exist")
         print("#" * 55 + "\n")
         return table

   table1 = table[table_names[0]]  # Giving different variables to tables that inserted.
   table2 = table[table_names[1]]

   try:
      if selected_column not in table1["columns"] or selected_column not in table2["columns"]:
         raise ValueError
   except ValueError:
      print(f"Column {selected_column} does not exist")
      print("#" * 55 + "\n")
      return table

   table1_columns = table1["columns"]  # In this part we give different variables to columns of tables and find the index of them in each table.
   table2_columns = table2["columns"]
   all_columns_index1 = table1["columns"].index(selected_column)
   all_columns_index2 = table2["columns"].index(selected_column)

   all_columns = table1_columns + table2_columns  # We add all the columns in a single dict
   all_data = []  # A new list to add all datas/rows that'll be printed

   for data1 in table1["person_data"]:  # Adding the datas to do list if the index matches
      for data2 in table2["person_data"]:
         if data1[all_columns_index1] == data2[all_columns_index2]:
            all_data.append(data1 + data2)

   print(f"Join result ({len(all_data)} rows):")
   print("\n" + f"Table: Joined Table")

   longest = []
   for c in all_columns:
      longest.append(len(c))
   for data in all_data:
      for a, b in enumerate(data):
         if len(str(b)) > longest[a]:
            longest[a] = len(str(b))

   line1 = "".join("+" + "-" * (l + 2) for l in longest)
   line2 = "".join("| " + c + " " * (l - len(c) + 1) for l, c in zip(longest, all_columns))
   print(line1 + "+")
   print(line2 + "|")
   print(line1 + "+")
   for datas in all_data:
      line3 = "".join("| " + d + " " * (l - len(d) + 1) for l, d in zip(longest, datas))
      print(line3 + "|")

   print(line1 + "+")
   print("#" * 55 + "\n")

   return table

def count(table, command):                       #Function for counting
   commands = command.split(" ", 3)
   person_name = commands[1]
   conditions = commands[3].split(",")

   print("#" * 22, "COUNT", "#" * 25)

   clean_conditions = {}
   if conditions == ['*']:  # If condition is "*" we count all the datas
      clean_conditions = {"*": "*"}
   else:
      for c in conditions:
         c = c.strip('{}')
         c_key, c_value = c.split(":")
         c_key = c_key.strip().strip('"')
         c_value = c_value.strip().strip('"')
         clean_conditions[c_key] = c_value

   try:
      sql = table[person_name]
   except KeyError:
      print(f"Table {person_name} not found")
      print(f"Total number of entries in '{person_name}' is 0")
      print("#" * 55 + "\n")
      return table

   try:
      no_column = [col for col in clean_conditions.keys() if col not in sql["columns"]]
      if no_column:
         raise ValueError
   except ValueError:
      print(f"Column {no_column[0]} does not exist")
      print(f"Total number of entries in '{person_name}' is 0")
      print("#" * 55 + "\n")
      return table

   counter = 0  # Adding numbers to counter if data matches the condition
   if clean_conditions == {"*": "*"}:
      counter = len(sql["person_data"])
   else:
      for data in sql["person_data"]:
         whole_data = dict(zip(sql["columns"], data))
         if all(
                 str(whole_data.get(key)) == str(value)
                 for key, value in clean_conditions.items()
         ):
            counter += 1
   print("Count:", counter)
   print(f"Total number of entries in '{person_name}' is {counter}")
   print("#" * 55 + "\n")

   return table

def main():
   f_in = open(argv[1], "r")
   command = f_in.readlines()
   table = {}

   for c in command:
      c = c.strip()
      if c.startswith("CREATE_TABLE"):
         table = create_table(table, c)
      elif c.startswith("INSERT"):
         table = insert(table, c)
      elif c.startswith("SELECT"):
         table = select(table, c)
      elif c.startswith("UPDATE"):
         table = update(table, c)
      elif c.startswith("DELETE"):
         table = delete(table,c)
      elif c.startswith("JOIN"):
         table = join(table, c)
      elif c.startswith("COUNT"):
         table = count(table, c)
      elif c.startswith(""):
         continue
      else:
         print("Please enter a suitable command for this part." + "\n")        #This part is for if command has aa writing or syntax error.

   f_in.close()

if __name__ == "__main__":
   main()

