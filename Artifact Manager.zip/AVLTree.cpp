#include "AVLTree.h"

AVLTree::AVLTree()
    : root(nullptr)
{
}

AVLTree::~AVLTree()
{
    clear();
}

void AVLTree::clear()
{
    clear(root);
    root = nullptr;
}

void AVLTree::clear(ArtifactNode *node)
{
    if (node == nullptr) {
        return;
    }

    clear(node->left);
    clear(node->right);
    delete node;
}

int AVLTree::height(ArtifactNode *node) const
{
    return node ? node->height : -1;
}

int AVLTree::getBalance(ArtifactNode *node) const
{
    if (!node) return 0;
    return height(node->left) - height(node->right);
}

ArtifactNode *AVLTree::rotateLeft(ArtifactNode *x)
{
    ArtifactNode *y = x->right;
    ArtifactNode *z = y->left; 
    y->left = x;
    x->right = z;
    x->height = std::max(height(x->left), height(x->right)) + 1;
    y->height = std::max(height(y->left), height(y->right)) + 1;

    return y;
}

ArtifactNode *AVLTree::rotateRight(ArtifactNode *y)
{
    ArtifactNode *x = y->left;
    ArtifactNode *z = x->right; 
    x->right = y;
    y->left = z;
    y->height = std::max(height(y->left), height(y->right)) + 1;
    x->height = std::max(height(x->left), height(x->right)) + 1;

    return x;
}

ArtifactNode *AVLTree::findMinNode(ArtifactNode *node) const
{
    if (node == nullptr) {
        return nullptr;
    }

    ArtifactNode *current = node;
    
    while (current->left != nullptr) {
        current = current->left;
    }

    return current;
}

ArtifactNode *AVLTree::insert(ArtifactNode *node, const Artifact &artifact, bool &inserted)
{
    if (node == nullptr)
    {
        inserted = true;
        return new ArtifactNode(artifact);
    }

    if (artifact.artifactID < node->data.artifactID)
    {
        node->left = insert(node->left, artifact, inserted);
    }
    else if (artifact.artifactID > node->data.artifactID)
    {
        node->right = insert(node->right, artifact, inserted);
    }
    else
    {
        inserted = false;
        return node;
    }

    if (!inserted)
        return node;

    node->height = 1 + std::max(height(node->left), height(node->right));

    int balance = getBalance(node);

    if (balance > 1 && getBalance(node->left) >= 0)
        return rotateRight(node);

    if (balance > 1 && getBalance(node->left) < 0)
    {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }

    if (balance < -1 && getBalance(node->right) <= 0)
        return rotateLeft(node);

    if (balance < -1 && getBalance(node->right) > 0)
    {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    return node;
}

ArtifactNode *AVLTree::remove(ArtifactNode *node, int artifactID, bool &removed)
{
    if (node == nullptr)
    {
        removed = false;
        return nullptr;
    }

    if (artifactID < node->data.artifactID)
        node->left = remove(node->left, artifactID, removed);

    else if (artifactID > node->data.artifactID)
        node->right = remove(node->right, artifactID, removed);

    else
    {
        removed = true;

        if (!node->left || !node->right)
        {
            ArtifactNode* child = node->left ? node->left : node->right;
            delete node;
            return child;
        }

        ArtifactNode* successor = findMinNode(node->right);
        node->data = successor->data;
        node->right = remove(node->right, successor->data.artifactID, removed);
    }

    node->height = 1 + std::max(height(node->left), height(node->right));
    int balance = getBalance(node);

    if (balance > 1 && getBalance(node->left) >= 0)
        return rotateRight(node);

    if (balance > 1 && getBalance(node->left) < 0)
    {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }

    if (balance < -1 && getBalance(node->right) <= 0)
        return rotateLeft(node);

    if (balance < -1 && getBalance(node->right) > 0)
    {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    return node;
}

bool AVLTree::insertArtifact(const Artifact &artifact)
{
    bool inserted = false;//tracks whether operation is succesful
    root = insert(root, artifact, inserted);
    return inserted;
}

bool AVLTree::removeArtifact(int artifactID)
{
    bool removed = false;//tracks whether operation is succesful
    root = remove(root, artifactID, removed);
    return removed;
}

ArtifactNode *AVLTree::findArtifact(int artifactID) const
{
    return find(root, artifactID);
}

ArtifactNode *AVLTree::find(ArtifactNode *node, int artifactID) const
{
    if (node == nullptr)
    {
        return nullptr;
    }

    if (artifactID < node->data.artifactID)
    {
        return find(node->left, artifactID);
    }

    else if (artifactID > node->data.artifactID)
    {
        return find(node->right, artifactID);
    }

    else
    {
        return node;
    }
}

void AVLTree::setAssignedTo(int artifactID, const std::string &researcherName)
{

    ArtifactNode *node = findArtifact(artifactID);
    if (node != nullptr)
    {
        node->data.assignedToName = researcherName; 
        node->data.updateValueBasedOnUsage(); 
    }

}

void AVLTree::clearAssignedTo(int artifactID)
{
    ArtifactNode *node = findArtifact(artifactID);
    if (node != nullptr)
    {
        node->data.assignedToName = ""; 
    }
}

void AVLTree::printUnassigned() const
{
    printUnassigned(root);
}

void AVLTree::printUnassigned(ArtifactNode *node) const
{
    if (node == nullptr)
    {
        return;
    }

    printUnassigned(node->left);

    if (node->data.assignedToName == "")
    {
        std::cout << node->data.artifactID << " " << node->data.name << " " << node->data.rarityLevel << " " << node->data.researchValue << std::endl;
    }

    printUnassigned(node->right);
}

int AVLTree::getArtifactCount() const
{
    return getArtifactCount(root);
}

int AVLTree::getArtifactCount(ArtifactNode *node) const
{
    if (node == nullptr)
    {
        return 0;
    }

    return getArtifactCount(node->left) + getArtifactCount(node->right) + 1;
}

int AVLTree::getTotalRarity() const
{
    return getTotalRarity(root);
}

int AVLTree::getTotalRarity(ArtifactNode *node) const
{
    if (node == nullptr)
    {
        return 0;
    }

    return getTotalRarity(node->left) + getTotalRarity(node->right) + node->data.rarityLevel;
}

void AVLTree::traversePostOrderForStats() const
{
    traversePostOrderForStats(root);
}

void AVLTree::traversePostOrderForStats(ArtifactNode *node) const
{
    if (node == nullptr) 
    return;

    traversePostOrderForStats(node->left);
    traversePostOrderForStats(node->right);
    std::cout << node->data.artifactID << " " << node->data.name << " " << node->data.rarityLevel << " " << node->data.researchValue << " ";
    
    if (node->data.assignedToName == "") {
        std::cout << "UNASSIGNED" << std::endl;
        
    } else {
        std::cout << node->data.assignedToName << std::endl; 
    }
}

void AVLTree::printMatchRarity(int minRarity) const {
    printMatchRarity(root, minRarity);
}

void AVLTree::printMatchRarity(ArtifactNode* node, int minRarity) const {

    if (node == nullptr) {
        return;
    }

    printMatchRarity(node->left, minRarity);

    if (node->data.rarityLevel >= minRarity) {
        std::cout << node->data.artifactID << " " << node->data.name << " " << node->data.rarityLevel << " " << node->data.researchValue;
        

        if (!node->data.assignedToName.empty()) {
            std::cout << " ASSIGNED:" << node->data.assignedToName;
        }
        std::cout << std::endl;
        
    }

    printMatchRarity(node->right, minRarity);
}

