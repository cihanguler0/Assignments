#include "Researcher.h"

Researcher::Researcher()
    : fullName(""),
      capacity(0),
      assignedArtifacts(nullptr),
      numAssigned(0)
{
}

Researcher::Researcher(const std::string &name, int cap)
    : fullName(name),
      capacity(cap),
      assignedArtifacts(nullptr),
      numAssigned(0)
{
    if (capacity > 0)
    {
        assignedArtifacts = new int[capacity];
    }
}




Researcher::~Researcher()
{
    delete[] assignedArtifacts;
    assignedArtifacts = nullptr;
}

bool Researcher::addArtifact(int artifactID)
{
    if (hasArtifact(artifactID)) {
        return false;
    }

    if (numAssigned >= capacity) {
        return false;
    }

    assignedArtifacts[numAssigned] = artifactID;
    numAssigned++;

    return true;
}

bool Researcher::removeArtifact(int artifactID)
{
    int targetIndex = -1;
    for (int i = 0; i < numAssigned; i++) {
        if (assignedArtifacts[i] == artifactID) {
            targetIndex = i;
            break;
        }
    }

    if (targetIndex == -1) {
        return false;
    }

    for (int i = targetIndex; i < numAssigned - 1; i++) {
        assignedArtifacts[i] = assignedArtifacts[i + 1];
    }

    numAssigned--;

    return true;
}

void Researcher::removeAllArtifacts()
{
   for (int i = 0; i < numAssigned; i++)
    {
        assignedArtifacts[i] = -1;
    }
    numAssigned = 0;
}

bool Researcher::hasArtifact(int artifactID) const
{
    for (int i = 0; i < numAssigned; i++) 
    {
        if (assignedArtifacts[i] == artifactID) 
        {
            return true;
        }
    }

    return false;
}

Researcher::Researcher(const Researcher &other): fullName(other.fullName), capacity(other.capacity), numAssigned(other.numAssigned) {
    
    assignedArtifacts = new int[capacity];
    
    for (int i = 0; i < numAssigned; i++) {
        assignedArtifacts[i] = other.assignedArtifacts[i];
    }
}

Researcher &Researcher::operator=(const Researcher &other) {
    if (this != &other) {

        delete[] assignedArtifacts; 
        fullName = other.fullName;
        capacity = other.capacity;
        numAssigned = other.numAssigned;
        assignedArtifacts = new int[capacity];

        for (int i = 0; i < numAssigned; i++) {
            assignedArtifacts[i] = other.assignedArtifacts[i];
        }
    }
    return *this;
}
