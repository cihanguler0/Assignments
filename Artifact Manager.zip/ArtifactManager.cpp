
#include "ArtifactManager.h"
#include <iostream>
#include <sstream>

ArtifactManager::ArtifactManager()
{
}

ArtifactManager::~ArtifactManager()
{
}

int ArtifactManager::tokenize(const std::string &line, std::string tokens[], int maxTokens) const
{
    std::istringstream iss(line);
    std::string tok;
    int count = 0;
    while (iss >> tok && count < maxTokens)
    {
        tokens[count++] = tok;
    }
    return count;
}

void ArtifactManager::parseAndExecute(const std::string &line)
{
    if (line.empty() || line[0] == '#')
    {
        return;
    }

    std::string tokens[10];
    int count = tokenize(line, tokens, 10);

    if (count == 0)
    {
        return;
    }

    std::string command = tokens[0];

    if (command == "ADD_ARTIFACT")
    {
        handleAddArtifact(tokens, count);
    }

    else if (command == "REMOVE_ARTIFACT")
    {
        handleRemoveArtifact(tokens, count);
    }

    else if (command == "HIRE_RESEARCHER")
    {
        handleHireResearcher(tokens, count);
    }

    else if (command == "FIRE_RESEARCHER")
    {
        handleFireResearcher(tokens, count);
    }

    else if (command == "REQUEST")
    {
        handleRequest(tokens, count);
    }

    else if (command == "RETURN")
    {
        handleReturn(tokens, count);
    }

    else if (command == "RETURN_ALL")
    {
        handleReturnAll(tokens, count);
    }

    else if (command == "RESEARCHER_LOAD")
    {
        handleResearcherLoad(tokens, count);
    }

    else if (command == "MATCH_RARITY")
    {
        handleMatchRarity(tokens, count);
    }

    else if (command == "PRINT_UNASSIGNED")
    {
        handlePrintUnassigned(tokens, count);
    }

    else if (command == "PRINT_STATS")
    {
        handlePrintStats(tokens, count);
    }

    else if (command == "CLEAR")
    {
        handleClear(tokens, count);
    }

    else
    {
        std::cout << "Error: Unknown command '" << command << "'." << std::endl;
    }
}

// =================== COMMAND HANDLERS ===================

void ArtifactManager::handleAddArtifact(const std::string tokens[], int count)
{
    if (count < 5) return;

    int id, rarity;
    long value;

    std::stringstream ss1(tokens[1]); 
    ss1 >> id;
    std::string name = tokens[2];
    std::stringstream ss3(tokens[3]); 
    ss3 >> rarity;
    std::stringstream ss4(tokens[4]); 
    ss4 >> value;
    Artifact newArt(id, name, rarity, value);

    if (artifactTree.insertArtifact(newArt)) 
    {
        std::cout << "Artifact " << id << " added." << std::endl;
    } 

    else 
    {
        std::cout << "Error: Duplicate artifact ID." << std::endl;
    }
}

void ArtifactManager::handleRemoveArtifact(const std::string tokens[], int count)
{
    if (count < 2) return;
    int id;
    std::stringstream ss(tokens[1]); 
    ss >> id;
    ArtifactNode* node = artifactTree.findArtifact(id);

    if (node) 
    {
        if (!node->data.assignedToName.empty()) 
        {
            ResearcherNode* rNode = researcherTree.findResearcher(node->data.assignedToName);
            if (rNode) rNode->data.removeArtifact(id);
        }

        if (artifactTree.removeArtifact(id)) 
        {
            std::cout << "Artifact " << id << " removed." << std::endl;
        }
    }
}

void ArtifactManager::handleHireResearcher(const std::string tokens[], int count)
{
    if (count < 3) return;
    std::string name = tokens[1];
    int capacity;
    std::stringstream ss(tokens[2]); 
    ss >> capacity;

    if (researcherTree.insertResearcher(Researcher(name, capacity))) 
    {
        std::cout << "Researcher " << name << " hired." << std::endl;
    } 

    else 
    {
        std::cout << "Error: Duplicate researcher name." << std::endl;
    }
}

void ArtifactManager::handleFireResearcher(const std::string tokens[], int count)
{
    if (count < 2) 
    return;

    std::string name = tokens[1];
    ResearcherNode* rNode = researcherTree.findResearcher(name);

    if (rNode) {
        
        int count = rNode->data.numAssigned;
        for (int i = 0; i < count; i++)
        {
            artifactTree.clearAssignedTo(rNode->data.assignedArtifacts[i]);
        }
        rNode->data.removeAllArtifacts();

        if (researcherTree.removeResearcher(name)) {
            std::cout << "Researcher " << name << " fired." << std::endl;
        }
        
    } else {
        std::cout << "Error: Researcher " << name << " not found." << std::endl;
    }
}

void ArtifactManager::handleRequest(const std::string tokens[], int count)
{
    if (count < 3) 
    return;

    std::string rName = tokens[1];
    int aID;
    std::stringstream ss(tokens[2]); ss >> aID;
    ResearcherNode* rNode = researcherTree.findResearcher(rName);
    ArtifactNode* aNode = artifactTree.findArtifact(aID);

    if (rNode && aNode) {
        
        if (!aNode->data.assignedToName.empty()) 
        return;

        if (rNode->data.numAssigned >= rNode->data.capacity) {
            std::cout << "Error: Researcher " << rName << " is at full capacity." << std::endl;
            return;
        }

        if (rNode->data.addArtifact(aID)) {
            artifactTree.setAssignedTo(aID, rName);
            std::cout << "Artifact " << aID << " assigned to " << rName << "." << std::endl;
        }
    }
}

void ArtifactManager::handleReturn(const std::string tokens[], int count)
{
    if (count < 3) 
    return;

    std::string rName = tokens[1];
    int aID;
    std::stringstream ss(tokens[2]); 
    ss >> aID;
    ArtifactNode* aNode = artifactTree.findArtifact(aID);
    
    if (aNode && aNode->data.assignedToName == rName) {
        ResearcherNode* rNode = researcherTree.findResearcher(rName);

        if (rNode) {
            
            rNode->data.removeArtifact(aID); 
            artifactTree.clearAssignedTo(aID);
            std::cout << "Artifact " << aID << " returned by " << rName << "." << std::endl;
        }
    }
}

void ArtifactManager::handleReturnAll(const std::string tokens[], int count)
{
    if (count < 2) return;
    std::string rName = tokens[1];
    ResearcherNode* rNode = researcherTree.findResearcher(rName);

    if (rNode) 
    {
        int count = rNode->data.numAssigned;
        for (int i = 0; i < count; i++)
        {
            artifactTree.clearAssignedTo(rNode->data.assignedArtifacts[i]);
        }
        rNode->data.removeAllArtifacts();
        std::cout << "All artifacts returned by " << rName << "." << std::endl;
    }
}

void ArtifactManager::handleResearcherLoad(const std::string tokens[], int count)
{
    if (count < 2) 
    return;

    std::string name = tokens[1];
    ResearcherNode* rNode = researcherTree.findResearcher(name);

    if (rNode) 
    {
        std::cout << "Researcher " << name << " is supervising " << rNode->data.numAssigned << " artifacts." << std::endl;
    }
}

void ArtifactManager::handleMatchRarity(const std::string tokens[], int count)
{
    if (count < 2) 
    return;

    int minRarity;
    std::stringstream ss(tokens[1]); 
    ss >> minRarity;
    std::cout << "=== MATCH_RARITY " << minRarity << " ===" << std::endl;
    artifactTree.printMatchRarity(minRarity);
}

void ArtifactManager::handlePrintUnassigned(const std::string tokens[], int count)
{
    std::cout << "Unassigned artifacts:" << std::endl;
    artifactTree.printUnassigned();
}

void ArtifactManager::handlePrintStats(const std::string tokens[], int count)
{
    int totalArt = artifactTree.getArtifactCount();
    int totalRes = researcherTree.getResearcherCount();
    int avgRarity = (totalArt > 0) ? artifactTree.getTotalRarity() / totalArt : 0;
    int avgLoad = (totalRes > 0) ? researcherTree.getTotalLoad() / totalRes : 0;

    std::cout << "=== SYSTEM STATISTICS ===" << std::endl;
    std::cout << "Artifacts: " << totalArt << std::endl;
    std::cout << "Researchers: " << totalRes << std::endl;
    std::cout << "Average rarity: " << avgRarity << std::endl;
    std::cout << "Average load: " << avgLoad << std::endl;
    std::cout << "Researchers:" << std::endl;
    researcherTree.traversePreOrderForStats();
    std::cout << "Artifacts:" << std::endl;
    artifactTree.traversePostOrderForStats();
}

void ArtifactManager::handleClear(const std::string tokens[], int count)
{
    artifactTree.clear();
    researcherTree.clear();
    std::cout << "All data cleared." << std::endl;
}
