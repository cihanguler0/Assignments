#include "RedBlackTree.h"

RedBlackTree::RedBlackTree() : root(nullptr) {}

RedBlackTree::~RedBlackTree()
{
    clear();
}

void RedBlackTree::clear()
{
    clear(root);
    root = nullptr;
}

void RedBlackTree::clear(ResearcherNode *node)
{
    if (!node) 
    return;

    clear(node->left);
    clear(node->right);

    delete node;
}

ResearcherNode *RedBlackTree::findResearcher(const std::string &fullName) const
{
    return find(root, fullName);
}

ResearcherNode *RedBlackTree::find(ResearcherNode *node, const std::string &fullName) const
{
    if (!node) return nullptr;

    if (fullName < node->data.fullName)
        return find(node->left, fullName);

    else if (fullName > node->data.fullName)
        return find(node->right, fullName);

    else
        return node;
}

bool RedBlackTree::insertResearcher(const Researcher &researcher)
{
    ResearcherNode *node = new ResearcherNode(researcher);
    bool inserted = false;

    root = bstInsert(root, node, inserted);

    if (!inserted)
    {
        delete node;
        return false;
    }

    insertFixup(node);
    return true;
}

ResearcherNode *RedBlackTree::bstInsert(ResearcherNode *current, ResearcherNode *node, bool &inserted)
{
    if (!current)
    {
        inserted = true;
        return node;
    }

    if (node->data.fullName < current->data.fullName)
    {
        current->left = bstInsert(current->left, node, inserted);
        if (current->left) current->left->parent = current;
    }

    else if (node->data.fullName > current->data.fullName)
    {
        current->right = bstInsert(current->right, node, inserted);
        if (current->right) current->right->parent = current;
    }

    else
    {
        inserted = false;
    }

    return current;
}

void RedBlackTree::insertFixup(ResearcherNode *node)
{
    while (node != root && node->parent->color == RED)
    {
        ResearcherNode *parent = node->parent;
        ResearcherNode *grand = parent->parent;

        if (parent == grand->left)
        {
            ResearcherNode *uncle = grand->right;

            if (uncle && uncle->color == RED)
            {
                parent->color = BLACK;
                uncle->color = BLACK;
                grand->color = RED;
                node = grand;
            }

            else
            {
                if (node == parent->right)
                {
                    node = parent;
                    rotateLeft(node);
                }
                parent->color = BLACK;
                grand->color = RED;
                rotateRight(grand);
            }
        }

        else
        {
            ResearcherNode *uncle = grand->left;

            if (uncle && uncle->color == RED)
            {
                parent->color = BLACK;
                uncle->color = BLACK;
                grand->color = RED;
                node = grand;
            }

            else
            {
                if (node == parent->left)
                {
                    node = parent;
                    rotateRight(node);
                }
                parent->color = BLACK;
                grand->color = RED;
                rotateLeft(grand);
            }
        }
    }
    root->color = BLACK;
}

bool RedBlackTree::removeResearcher(const std::string &fullName)
{
    ResearcherNode *z = findResearcher(fullName);
    if (!z) 
    return false;

    ResearcherNode *y = z;
    ResearcherNode *x = nullptr;
    ResearcherNode *xParent = nullptr;
    Color yOriginalColor = y->color;

    if (!z->left)
    {
        x = z->right;
        xParent = z->parent;

        if (z->parent)
        {
            if (z == z->parent->left) z->parent->left = z->right;
            else z->parent->right = z->right;
        }

        else root = z->right;

        if (z->right) z->right->parent = z->parent;
    }

    else if (!z->right)
    {
        x = z->left;
        xParent = z->parent;

        if (z->parent)
        {
            if (z == z->parent->left) 
            z->parent->left = z->left;

            else 
            z->parent->right = z->left;
        }
        else 
        root = z->left;

        if (z->left) 
        z->left->parent = z->parent;
    }

    else
    {
        y = minimum(z->right);
        yOriginalColor = y->color;
        x = y->right;

        if (y->parent == z)
        {
            xParent = y;
            if (x) x->parent = y;
        }

        else
        {
            xParent = y->parent;

            if (y->parent->left == y) 
            y->parent->left = y->right;

            else 
            y->parent->right = y->right;

            if (y->right) y->right->parent = y->parent;

            y->right = z->right;
            y->right->parent = y;
        }

        if (z->parent)
        {
            if (z == z->parent->left) z->parent->left = y;
            else z->parent->right = y;
        }

        else root = y;

        y->parent = z->parent;
        y->left = z->left;
        y->left->parent = y;
        y->color = z->color;
    }

    delete z;

    if (yOriginalColor == BLACK)
        deleteFixup(x, xParent);

    return true;
}

void RedBlackTree::deleteFixup(ResearcherNode *x, ResearcherNode *parent)
{
    while (x != root && (!x || x->color == BLACK))
    {
        if (x == parent->left)
        {
            ResearcherNode *w = parent->right;

            if (w && w->color == RED)
            {
                w->color = BLACK;
                parent->color = RED;
                rotateLeft(parent);
                w = parent->right;
            }

            if ((!w->left || w->left->color == BLACK) &&
                (!w->right || w->right->color == BLACK))
            {
                w->color = RED;
                x = parent;
                parent = x->parent;
            }

            else
            {
                if (!w->right || w->right->color == BLACK)
                {
                    if (w->left) w->left->color = BLACK;
                    w->color = RED;
                    rotateRight(w);
                    w = parent->right;
                }

                w->color = parent->color;
                parent->color = BLACK;
                if (w->right) w->right->color = BLACK;
                rotateLeft(parent);
                x = root;
            }
        }

        else
        {
            ResearcherNode *w = parent->left;

            if (w && w->color == RED)
            {
                w->color = BLACK;
                parent->color = RED;
                rotateRight(parent);
                w = parent->left;
            }

            if ((!w->right || w->right->color == BLACK) &&
                (!w->left || w->left->color == BLACK))
            {
                w->color = RED;
                x = parent;
                parent = x->parent;
            }
            else
            {
                if (!w->left || w->left->color == BLACK)
                {
                    if (w->right) w->right->color = BLACK;
                    w->color = RED;
                    rotateLeft(w);
                    w = parent->left;
                }

                w->color = parent->color;
                parent->color = BLACK;
                if (w->left) w->left->color = BLACK;
                rotateRight(parent);
                x = root;
            }
        }
    }

    if (x) x->color = BLACK;
}

void RedBlackTree::rotateLeft(ResearcherNode *x)
{
    ResearcherNode *y = x->right;
    x->right = y->left;

    if (y->left) 
    y->left->parent = x;

    y->parent = x->parent;

    if (!x->parent) 
    root = y;

    else if (x == x->parent->left) 
    x->parent->left = y;

    else 
    x->parent->right = y;

    y->left = x;
    x->parent = y;
}

void RedBlackTree::rotateRight(ResearcherNode *y)
{
    ResearcherNode *x = y->left;
    y->left = x->right;

    if (x->right) x->right->parent = y;

    x->parent = y->parent;

    if (!y->parent) 
    root = x;

    else if (y == y->parent->left) 
    y->parent->left = x;

    else 
    y->parent->right = x;

    x->right = y;
    y->parent = x;
}

ResearcherNode *RedBlackTree::minimum(ResearcherNode *node) const
{
    while (node && node->left)
        node = node->left;

    return node;
}

int RedBlackTree::getResearcherCount(ResearcherNode *node) const
{
    if (!node) 
    return 0;

    return getResearcherCount(node->left) + getResearcherCount(node->right) + 1;
}

int RedBlackTree::getTotalLoad(ResearcherNode *node) const
{
    if (!node) 
    return 0;

    return node->data.numAssigned + getTotalLoad(node->left) +getTotalLoad(node->right);
}

void RedBlackTree::traversePreOrderForStats(ResearcherNode *node) const
{
    if (!node) 
    return;

    std::cout << node->data.fullName << " "<< node->data.capacity << " " << node->data.numAssigned << std::endl;

    traversePreOrderForStats(node->left);
    traversePreOrderForStats(node->right);
}

int RedBlackTree::getResearcherCount() const
{
    return getResearcherCount(root);
}

int RedBlackTree::getTotalLoad() const
{
    return getTotalLoad(root);
}

void RedBlackTree::traversePreOrderForStats() const
{
    traversePreOrderForStats(root);
}
