#include "Artifact.h"

Artifact::Artifact()
    : artifactID(-1),
      name(""),
      rarityLevel(1),
      researchValue(0),
      assignedToName("")
{
}

Artifact::Artifact(int id, const std::string &n, int rarity, int value)
    : artifactID(id),
      name(n),
      rarityLevel(rarity),
      researchValue(value),
      assignedToName("")
{
}

void Artifact::updateValueBasedOnUsage()
{
  this->counter++; 
  this->researchValue += (this->rarityLevel * this->counter); 
}
