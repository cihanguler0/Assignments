.data
A:      .word 495, 10, 864, 22, 0, 24
size:   .word 6
thresh: .word 40
str_notes:    .asciiz "data[] = {"
str_comma:    .asciiz ", "
str_end:      .asciiz "}\n"
str_sus:      .asciiz "count_suspicious (threshold=40) = "
str_nl:       .asciiz "\n"
str_ids:      .asciiz "Bonus: Cheaters IDs: "
str_and:      .asciiz " and "
str_cheaters: .asciiz "The cheaters are "
name1: .asciiz "Inek Saban"
name2: .asciiz "Guduk Necmi"
name3: .asciiz "Damat Ferit"
name4: .asciiz "Domdom Ali"
name5: .asciiz "Tulum Hayri"
name6: .asciiz "Hayta Ismail"
 
name_table:
    .word name1, name2, name3, name4, name5, name6
 
        .text
        .globl main
        
main:
 
        # TODO: Part 1 - decrypt the array (50 pts)
        #   for (int i = 0; i < datasize; i++)
        #       if (i % 2 == 0) data[i] = data[i] / 9;
        #       else            data[i] = data[i] * 3;
        #   No mul/mult/div allowed (-10 penalty)
        
        la   $t0, A
        lw   $t1, size  
        li   $t2, 0     # $t2 will be our index
        
loop:  
 
        beq  $t2, $t1, end     # If i = size exit loop.
        lw   $t3, 0($t0)       # Reaching our data.
        andi $t4, $t2, 1       # Checkinf if our index is odd or even.
        li   $t6, 9            # This part is for dividng number 9 in even section.
        li   $t7, 0
        beq  $t4, $zero, even  # If t4 = 0 it means it's even
        
odd:
        sll  $t5, $t3, 1
        add  $t3, $t5, $t3
        j    update_array
        
even:   
 
        blt  $t3, $t6, even_done 
        sub  $t3, $t3, $t6       
        addi $t7, $t7, 1        
        j    even
        
even_done:
 
        move $t3, $t7      
                  
        # TODO: Print and count (see instructions for output format)
        
update_array:
 
        sw   $t3, 0($t0)    # Save our real (decrypted) number to array)
        addi $t0, $t0, 4    # Increase our position 4 bytes
        addi $t2, $t2, 1    # i++
        j loop
        
end:
 
        la   $a0, str_notes
        li   $v0, 4
        syscall
 
        la   $t0, A
        lw   $t1, size
        li   $t2, 0
        
print_loop:
 
        lw   $a0, 0($t0)
        li   $v0, 1
        syscall
        addi $t2, $t2, 1
        beq  $t2, $t1, print_done
        la   $a0, str_comma
        li   $v0, 4
        syscall
        addi $t0, $t0, 4
        j    print_loop
        
print_done:
 
        la   $a0, str_end
        li   $v0, 4
        syscall
        
        # This part is like a preperation for our recursive calls.
 
        la   $a0, A            
        lw   $a1, size         
        lw   $a2, thresh
        jal  count_suspicious
        
        la   $a0, str_sus
        li   $v0, 4
        syscall
        move $a0, $v1
        li   $v0, 1
        syscall
        la   $a0, str_nl
        li   $v0, 4
        syscall
 
        la   $t0, A           
        lw   $t1, size        
        li   $t2, 0    # Our index         
        li   $t3, 2    # Row     
        li   $t4, 1    # Column        
        li   $s6, 0    # First cheating student.   
        li   $s7, 0    # Second cheating student.       
        
find_loop:

        beq  $t2, $t1, find_done
 
      
        sll  $t5, $t2, 2            # Calculating our offset: Index x 4 
        add  $t5, $t0, $t5          # Calculating our adress: base adress + offset 
        lw   $t6, 0($t5)        
        li   $t7, 80
        blt  $t6, $t7, not_cheat    # score<80 means no cheating.
 
      
        move $s6, $t4               # Storing first cheater's id.
        move $s7, $t3               # Storing second cheater's id.
        j    find_done
 
not_cheat:
     
        addi $t4, $t4, 1            # Increase column index
        beq  $t4, $t3, next_row     # If column = row move next row
        addi $t2, $t2, 1            # Increase overall array index
        j    find_loop
 
next_row:
        addi $t3, $t3, 1            # Increase row index.
        li   $t4, 1                 # Reset column index
        addi $t2, $t2, 1            # Increase overall array index
        j    find_loop
 
find_done:
 

        la   $a0, str_ids
        li   $v0, 4
        syscall
 
        move $a0, $s6
        li   $v0, 1
        syscall
 
        la   $a0, str_and
        li   $v0, 4
        syscall
 
        move $a0, $s7
        li   $v0, 1
        syscall
 
        la   $a0, str_nl
        li   $v0, 4
        syscall
 
        la   $a0, str_cheaters
        li   $v0, 4
        syscall
 
        la   $t0, name_table
        addi $t1, $s6, -1       
        sll  $t1, $t1, 2       
        add  $t0, $t0, $t1
        lw   $a0, 0($t0)
        li   $v0, 4
        syscall
 
        la   $a0, str_and
        li   $v0, 4
        syscall
 
        la   $t0, name_table    # Reaching base address of the name pointer table.
        addi $t1, $s7, -1       # Id = Index + 1
        sll  $t1, $t1, 2        # Multiplying our index by 4, ao we can reach the certain word
        add  $t0, $t0, $t1      # Calculating address
        lw   $a0, 0($t0)        # Find the name
        li   $v0, 4
        syscall
 
        la   $a0, str_nl
        li   $v0, 4
        syscall
 
        li   $v0, 10            # End program
        syscall
        
# Do NOT rename this label
 
count_suspicious:
 
        # TODO: Part 2 - recursive count (50 pts)
        #   int count_suspicious(int *data, int n, int threshold)
        #   $a0 = array, $a1 = n, $a2 = threshold, return in $v1
        #   Must use jal, must be recursive
        
        addi $sp, $sp, -20     # Creating stack frame
        sw   $ra, 16($sp)      # Save return adress.
        sw   $a1, 12($sp)      # Save current n
        sw   $a2,  8($sp)      # Save thresh
        sw   $a0,  4($sp)      # Save array base adress
        sw   $s0,  0($sp)      
       
        li   $v1, 0
        
        beq  $a1, $zero, end2  # If n = 0 return 0 
        addi $a1, $a1, -1      # n - 1 for our recursion
        jal  count_suspicious
        
        move $s0, $v1          # Save the result of our recursion
        
        lw   $a0,  4($sp)      # Restore array adress 
        lw   $a2,  8($sp)      # Restore thresh
        lw   $t0, 12($sp)      # Restore original n
        addi $t0, $t0, -1      # Index = n - 1
        sll  $t1, $t0, 2       # Converting index to offset
        add  $t1, $a0, $t1     
        lw   $t2, 0($t1)       
        blt  $t2, $a2, skip    # If data[n-1] < thresh, do not increae
        addi $s0, $s0, 1       
        
skip:
        move $v1, $s0
        
end2: 
        lw   $s0,  0($sp)
        lw   $a0,  4($sp)      
        lw   $a2,  8($sp)      
        lw   $a1, 12($sp)
        lw   $ra, 16($sp)      # Restore return address
        addi $sp, $sp, 20
        jr   $ra               # Return to caller
