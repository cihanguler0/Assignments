import java.io.*;
import java.util.ArrayList;
import java.util.List;

// Base class of library users

public class Users {
    private String itemClass;       // In this part you can see our variables. They are all private because we need an encapsulated code.
    private int id;
    private String name;
    private String phoneNumber;
    private int borrowedNum;
    private int penalty;

    // Constructor Part

    public Users(String itemClass, String name, int id, String phoneNumber) {
        this.itemClass = itemClass;
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.borrowedNum = 0;
        this.penalty = 0;
    }

    // Getters for our variables.

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public int getBorrowedNum() {
        return borrowedNum;
    }

    // Our functions which manages borrow counts

    public void incrementBorrowedNum() {
        borrowedNum++;
    }

    public void decrementBorrowedNum() {
        borrowedNum--;
    }

    // Our functions which manages penalties

    public int getPenalty() {
        return penalty;
    }

    public void addPenalty(int amount) {
        this.penalty += amount;
    }

    public void clearPenalty() {
        this.penalty = 0;
    }

    public int getMaxBorrowDays() {
        return Integer.MAX_VALUE;
    }

    public boolean canBorrow(List<Items> items) { // Our function that checks can user borrow the item or not.
        if (penalty >= 6) { // This part checks penalty
            return false;
        }

        int currentBorrowed = 0;

        for (Items item : items) {
            if (item.getStatus().equals("Borrowed") && item.getBorrowedBy().equals(name)) {
                currentBorrowed++;
            }
        }

        return currentBorrowed < getMaxBorrowLimit(); // This part checks did userexceed the limit.
    }

    public int getMaxBorrowLimit() {   // Max Borrow Limits for users
        if (this instanceof Students) return 5;
        if (this instanceof AcademicStaff) return 3;
        if (this instanceof Guests) return 1;
        return 0;
    }

    public static List<Users> readTxt(String input) {
        List<Users> userList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(input))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals("S")) {
                    Students student = new Students(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3], parts[4], parts[5], Integer.parseInt(parts[6]));
                    userList.add(student);
                } else if (parts[0].equals("A")) {
                    AcademicStaff aStaff = new AcademicStaff(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3], parts[4], parts[5], parts[6]);
                    userList.add(aStaff);
                } else if (parts[0].equals("G")) {
                    Guests guest = new Guests(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3], parts[4]);
                    userList.add(guest);
                } else {
                    Users user = new Users(parts[0], parts[1], Integer.parseInt(parts[2]), parts[parts.length - 1]);
                    userList.add(user);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return userList;
    }

    public String infos() {
        return "Class: " + itemClass + ", ID: " + id + ", Name: " + name + ", PhoneNumber: " + phoneNumber;
    }
}

class Students extends Users {   // Sub-Class students part.
    private String department;
    private String faculty;
    private int grade;
    private static final int MAX_BORROW = 5;

    public Students(String itemClass, String name, int id, String phoneNumber, String department, String faculty, int grade) {
        super(itemClass, name, id, phoneNumber);
        this.department = department;
        this.faculty = faculty;
        this.grade = grade;
    }

    public String getFaculty() {
        return faculty;
    }

    public String getDepartment() {
        return department;
    }

    public int getGrade() {
        return grade;
    }

    public int getMaxBorrowDays() {
        return 30;
    }

    public String infos() {
        return super.infos() + ", Faculty: " + faculty + ", Department: " + department + ", Grade: " + grade;
    }
}

class AcademicStaff extends Users {   // Sub-Class academic staff part.
    private String department;
    private String faculty;
    private String title;
    private static final int MAX_BORROW = 3;

    public AcademicStaff(String itemClass, String name, int id, String phoneNumber, String department, String faculty, String title) {
        super(itemClass, name, id, phoneNumber);
        this.department = department;
        this.faculty = faculty;
        this.title = title;
    }

    public String getFaculty() {
        return faculty;
    }

    public String getDepartment() {
        return department;
    }

    public String getTitle() {
        return title;
    }

    public int getMaxBorrowDays() {
        return 15;
    }

    public String infos() {
        return super.infos() + ", Faculty: " + faculty + ", Department: " + department + ", Title: " + title;
    }
}

class Guests extends Users {   // Sub-Class guests part.
    private String occupation;
    private static final int MAX_BORROW = 1;

    public Guests(String itemClass, String name, int id, String phoneNumber, String occupation) {
        super(itemClass, name, id, phoneNumber);
        this.occupation = occupation;
    }

    public String getOccupation() {
        return occupation;
    }

    public int getMaxBorrowDays() {
        return 7;
    }

    public String infos() {
        return super.infos() + ", Occupation: " + occupation;
    }
}


