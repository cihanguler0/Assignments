import java.io.*;
import java.util.ArrayList;
import java.util.List;

// Base class of library items.

public class Items {    // In this part you can see our variables. They are all private because we need an encapsulated code.
    private String itemClass;
    private int id;
    private String title;
    private String type;
    private String status;
    private String borrowedBy;
    private String borrowDate;

    // Constructor Part

    public Items(String itemClass, int id, String title, String type) {
        this.itemClass = itemClass;
        this.id = id;
        this.title = title;
        this.type = type;
        this.status = "Available";
        this.borrowedBy = "";
        this.borrowDate = "";
    }

    // Getters for our variables.

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getType() {
        return type;
    }

    public String getStatus() {
        return status;
    }

    public String getBorrowedBy() {
        return borrowedBy;
    }

    public String getBorrowDate() {
        return borrowDate;
    }

    // Our functions which manages bitem statuses

    public void setStatus(String status) {
        this.status = status;
    }

    public void setBorrowedBy(String name) {
        this.borrowedBy = name;
    }

    public void setBorrowDate(String date) {
        this.borrowDate = date;
    }

    // These functions check item types because there are some restrictions for users.

    public boolean isReferenceItem() {
        return this.getType().equalsIgnoreCase("reference");
    }

    public boolean isRareItem() {
        return this.getType().equalsIgnoreCase("rare");
    }

    public boolean isLimitedItem() {
        return this.getType().equalsIgnoreCase("limited");
    }

    public static List<Items> readTxt(String input) {
        List<Items> itemList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(input))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals("B")) {
                    Books book = new Books(parts[0], Integer.parseInt(parts[1]), parts[2], parts[3], parts[4], parts[5]);
                    itemList.add(book);
                } else if (parts[0].equals("M")) {
                    Magazines magazine = new Magazines(parts[0], Integer.parseInt(parts[1]), parts[2], parts[3], parts[4], parts[5]);
                    itemList.add(magazine);
                } else if (parts[0].equals("D")) {
                    DVDs dvd = new DVDs(parts[0], Integer.parseInt(parts[1]), parts[2], parts[3], parts[4], parts[5], parts[6]);
                    itemList.add(dvd);
                } else {
                    Items item = new Items(parts[0], Integer.parseInt(parts[1]), parts[2], parts[parts.length - 1]);
                    itemList.add(item);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return itemList;
    }

    public String infos() {
        String info = "Class: " + itemClass + ", ID: " + id + ", Title: " + title + ", Type: " + type + ", Status: " + status;
        if (status.equals("Borrowed")) {
            info += ", Borrowed Date: " + borrowDate + ", Borrowed by: " + borrowedBy;
        }
        return info;
    }
}

class Books extends Items {   // Sub-Class books part.
    private String author;
    private String category;

    public Books(String itemClass, int id, String title, String author, String category, String type) {
        super(itemClass, id, title, type);
        this.author = author;
        this.category = category;
    }

    public String getAuthor() {
        return author;
    }

    public String getCategory() {
        return category;
    }

    public String infos() {
        return super.infos() + ", Author: " + author + ", Category: " + category;
    }
}

class Magazines extends Items {   // Sub-Class magazines part.
    private String publisher;
    private String category;

    public Magazines(String itemClass, int id, String title, String publisher, String category, String type) {
        super(itemClass, id, title, type);
        this.publisher = publisher;
        this.category = category;
    }

    public String getPublisher() {
        return publisher;
    }

    public String getCategory() {
        return category;
    }

    public String infos() {
        return super.infos() + ", Publisher: " + publisher + ", Category: " + category;
    }
}

class DVDs extends Items {   // Sub-Class DVDs part.
    private String director;
    private String category;
    private String runTime;

    public DVDs(String itemClass, int id, String title, String director, String category, String runTime, String type) {
        super(itemClass, id, title, type);
        this.director = director;
        this.category = category;
        this.runTime = runTime;
    }

    public String getDirector() {
        return director;
    }

    public String getCategory() {
        return category;
    }

    public String getRunTime() {
        return runTime;
    }

    public String infos() {
        return super.infos() + ", Director: " + director + ", Category: " + category + ", RunTime: " + runTime;
    }
}