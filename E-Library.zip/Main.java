import java.io.*;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

//  Main class for our library

public class Main {
    private static PrintWriter outputWriter;  // Our output writer function

    // Below, there are our arguments.

    public static void main(String[] args) {
        String itemsFile = args[0];
        String usersFile = args[1];
        String commandFile = args[2];
        String outputFile = args[3];

        try {
            outputWriter = new PrintWriter(new FileWriter(outputFile));

            List<Items> items = Items.readTxt(itemsFile);
            List<Users> users = Users.readTxt(usersFile);
            readCommands(commandFile, items, users);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (outputWriter != null) {
                outputWriter.close();
            }
        }
    }

    public static void readCommands(String fileName, List<Items> items, List<Users> users) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String command;
            while ((command = br.readLine()) != null) {
                String[] parts = command.split(",");
                processCommand(parts, items, users);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // This part checks is there any overdue items on anyone if someone tries to borrow something.
    // I used formatter for this part because Java accepts dates originally in yyyy/mm/dd format.

    public static void returnOverdueItems(List<Users> users, List<Items> items, String currentDateStr) {
        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        LocalDate today = LocalDate.now();
        LocalDate inputDate;
        try {
            try {
                inputDate = LocalDate.parse(currentDateStr, formatter1);
            } catch (DateTimeParseException e1) {
                inputDate = LocalDate.parse(currentDateStr, formatter2);
            }
        } catch (DateTimeParseException e) {
            return;
        }

        for (Users user : users) {
            for (Items item : items) {
                if ("Borrowed".equals(item.getStatus()) && user.getName().equals(item.getBorrowedBy())) {
                    String borrowDateStr = item.getBorrowDate();
                    if (borrowDateStr == null || borrowDateStr.isEmpty()) continue;

                    LocalDate borrowDate;
                    try {
                        try {
                            borrowDate = LocalDate.parse(borrowDateStr, formatter1);
                        } catch (DateTimeParseException e1) {
                            borrowDate = LocalDate.parse(borrowDateStr, formatter2);
                        }
                    } catch (DateTimeParseException e) {
                        continue;
                    }

                    long daysBetween = ChronoUnit.DAYS.between(borrowDate, today);

                    if (daysBetween > user.getMaxBorrowDays()) {
                        user.addPenalty(2);
                        item.setStatus("Available");
                        item.setBorrowedBy(null);
                        item.setBorrowDate(null);
                        user.decrementBorrowedNum();
                    }
                }
            }
        }
    }

    // This part precess our commands like borrow, return, pay or display.

    public static void processCommand(String[] parts, List<Items> items, List<Users> users) {
        String command = parts[0].trim();

        if (command.equals("displayItems")) {
            outputWriter.print("\n");
            for (Items item : items) {
                outputWriter.println("\n------ Item Information for " + item.getId() + " ------");
                outputWriter.print("ID: " + item.getId() + " Name: " + item.getTitle() + " Status: " + item.getStatus());
                if (item.getStatus() == "Borrowed") {
                    DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    String formattedDate = item.getBorrowDate();
                    if (!formattedDate.isEmpty()) {
                        LocalDate borrowDate = LocalDate.parse(formattedDate);
                        formattedDate = borrowDate.format(outputFormatter);
                    }
                    outputWriter.print(" Borrowed Date: " + formattedDate + " Borrowed by: " + item.getBorrowedBy());
                }
                if (item instanceof Books) {
                    Books book = (Books) item;
                    outputWriter.print("\nAuthor: " + book.getAuthor() + " Genre: " + book.getCategory() + "\n");
                }
                else if (item instanceof Magazines) {
                    Magazines magazine = (Magazines) item;
                    outputWriter.print("\nPublisher: " + magazine.getPublisher() + " Category: " + magazine.getCategory() + "\n");
                }
                else {
                    DVDs dvd = (DVDs) item;
                    outputWriter.print("\nDirector: " + dvd.getDirector() + " Category: " + dvd.getCategory() + " Runtime: " + dvd.getRunTime() + "\n");
                }
            }
            return;
        } else if (command.equals("displayUsers")) {
            outputWriter.print("\n");
            for (Users user : users) {
                outputWriter.println("\n------ User Information for " + user.getId() + " ------");
                if (user instanceof AcademicStaff) {
                    AcademicStaff academicStaff = (AcademicStaff) user;
                    outputWriter.println("Name: " + academicStaff.getTitle() + " " + user.getName() + " Phone: " + user.getPhoneNumber());
                }
                else {
                    outputWriter.println("Name: " + user.getName() + " Phone: " + user.getPhoneNumber());
                }
                if (user instanceof Students) {
                    Students students = (Students) user;
                    outputWriter.println("Faculty: " + students.getFaculty() + " Department: " + students.getDepartment() + " Grade: " + students.getGrade()+"th");
                }
                else if (user instanceof AcademicStaff) {
                    AcademicStaff academicStaff = (AcademicStaff) user;
                    outputWriter.println("Faculty: " + academicStaff.getFaculty() + " Department: " + academicStaff.getDepartment());
                }
                else {
                    Guests guests = (Guests) user;
                    outputWriter.println("Occupation: " + guests.getOccupation());
                }
                if (user.getPenalty() > 0) {
                    outputWriter.println("Penalty: " + user.getPenalty() + "$");
                }
            }
            return;
        }

        int userID = Integer.parseInt(parts[1]);
        Users borrower = userFinder(users, userID);

        if (command.equals("pay")) {
            if (borrower != null) {
                if (borrower.getPenalty() > 0) {
                    outputWriter.println(borrower.getName() + " has paid penalty");
                    borrower.clearPenalty();
                } else {
                    return;
                }
            } else {
                return;
            }
            return;
        }

        int itemID = Integer.parseInt(parts[2]);
        Items borrowed = itemFinder(items, itemID);

        if (command.equals("borrow")) {
            String currentDate = parts[parts.length - 1];
            returnOverdueItems(users, items, currentDate);
            if (borrower != null && borrowed != null) {

                if (borrowed.getStatus().equalsIgnoreCase("Borrowed")) {
                    outputWriter.println(borrower.getName() + " cannot borrow " + borrowed.getTitle() + ", it is not available!");
                    return;
                }

                if (borrower instanceof Students && borrowed.isReferenceItem()) {
                    outputWriter.println(borrower.getName() + " cannot borrow reference item!");
                    return;
                }

                if (borrower instanceof Guests && borrowed.isRareItem()) {
                    outputWriter.println(borrower.getName() + " cannot borrow rare item!");
                    return;
                }

                if (borrower instanceof Guests && borrowed.isLimitedItem()) {
                    outputWriter.println(borrower.getName() + " cannot borrow limited item!");
                    return;
                }

                if (!borrower.canBorrow(items)) {
                    if (borrower.getPenalty() >= 6) {
                        outputWriter.println(borrower.getName() + " cannot borrow " + borrowed.getTitle() + ", you must first pay the penalty amount! " + borrower.getPenalty() + "$");
                    } else if (borrower.getBorrowedNum() >= borrower.getMaxBorrowLimit()) {
                        outputWriter.println(borrower.getName() + " cannot borrow " + borrowed.getTitle() + ", since the borrow limit has been reached!");
                    }
                } else {
                    borrower.incrementBorrowedNum();
                    borrowed.setStatus("Borrowed");
                    borrowed.setBorrowedBy(borrower.getName());
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate borrowDate = LocalDate.parse(parts[3], formatter);
                    borrowed.setBorrowDate(borrowDate.toString());
                    outputWriter.println(borrower.getName() + " successfully borrowed! " + borrowed.getTitle());
                }
            } else {
                outputWriter.println("Unknown Command.");
            }
        } else if (command.equals("return")) {
            if (borrower != null && borrowed != null) {
                borrower.decrementBorrowedNum();
                borrowed.setStatus("Available");
                borrowed.setBorrowedBy("");
                borrowed.setBorrowDate("");
                outputWriter.println(borrower.getName() + " successfully returned " + borrowed.getTitle());
            } else {
                outputWriter.println("Unknown Command.");
            }
        } else {
            outputWriter.println("Unknown Command.");
        }
    }

    // This two functions for achieving other infos about our items our users by their id from inputs.

    private static Users userFinder(List<Users> users, int id) {
        for (Users user : users) {
            if (user.getId() == id) {
                return user;
            }
        }
        return null;
    }

    private static Items itemFinder(List<Items> items, int id) {
        for (Items item : items) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }
}