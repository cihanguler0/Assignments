import java.util.List;
import java.util.ArrayList;
import java.util.Stack;

public class BootSequence {

    private static final int WHITE = 0;
    private static final int GRAY = 1;
    private static final int BLACK = 2;

    public static List<Integer> computeBootSequence(Digraph g, String[] labels) {

        int V = g.V();
        int[] color = new int[V];
        Stack<Integer> topoStack = new Stack<>();
        List<Integer> bootSequence = new ArrayList<>();
        int cycleFrom = -1, cycleTo = -1;

        for (int i = 0; i < V; i++) {

            if (color[i] == WHITE) {

                int[] cycleInfo = dfs(i, g, color, topoStack);

                if (cycleInfo[0] != -1) {

                    cycleFrom = cycleInfo[0];
                    cycleTo = cycleInfo[1];
                    break;

                }
            }
        }

        System.out.println("=== Part B: Master Boot Sequence ===");

        if (cycleFrom != -1) {

            System.out.printf("  [Cycle detected] Edge %d → %d creates a circular dependency.%n", cycleFrom, cycleTo);
            System.out.println("SYSTEM INFEASIBLE: Circular reference (deadlock) detected!");
            return bootSequence;

        }

        int step = 1;
        System.out.println("Valid boot sequence found:");

        while (!topoStack.isEmpty()) {

            int vertex = topoStack.pop();
            bootSequence.add(vertex);
            System.out.printf("  Step %2d: %-22s (id=%d)%n", step++, labels[vertex], vertex);

        }

        return bootSequence;
    }

    private static int[] dfs(int v, Digraph g, int[] color, Stack<Integer> topoStack) {

        color[v] = GRAY;

        for (int w : g.adj(v)) {

            if (color[w] == GRAY) {

                return new int[]{v, w};

            }

            if (color[w] == WHITE) {

                int[] result = dfs(w, g, color, topoStack);

                if (result[0] != -1) {

                    return result;

                }
            }
        }

        color[v] = BLACK;
        topoStack.push(v);
        return new int[]{-1, -1};
        
    }
}
