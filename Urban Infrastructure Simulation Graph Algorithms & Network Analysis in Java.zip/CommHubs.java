import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;
 
public class CommHubs {
 
    public static void findHighInteractionZones(Digraph g, String[] labels) {
 
        System.out.println("=== Part C: Secure Communication Hubs ===");
        int V = g.V();
        boolean[] visited = new boolean[V];
        Stack<Integer> finishOrder = new Stack<>();
 
        for (int v = 0; v < V; v++) {

            if (!visited[v]) {

                dfs1(g, v, visited, finishOrder);

            }
        }
 
        Digraph rev = g.reverse();
        boolean[] visited2 = new boolean[V];
        List<List<Integer>> sccs = new ArrayList<>();
 
        while (!finishOrder.isEmpty()) {

            int v = finishOrder.pop();

            if (!visited2[v]) {

                List<Integer> scc = new ArrayList<>();
                dfs2(rev, v, visited2, scc);
                sccs.add(scc);

            }
        }
 
        Collections.reverse(sccs);
        System.out.println("Total SCCs found: " + sccs.size());
        int highInteractionCount = 0;
 
        for (int i = 0; i < sccs.size(); i++) {

            List<Integer> scc = sccs.get(i);
            boolean isHigh = scc.size() > 1;

            if (isHigh) highInteractionCount++;
 
            StringBuilder sb = new StringBuilder();
            sb.append("  SCC-").append(i);

            if (isHigh) sb.append(" [HIGH-INTERACTION ZONE]");

            sb.append(": {");

            for (int j = 0; j < scc.size(); j++) {

                if (j > 0) sb.append(", ");

                sb.append(labels[scc.get(j)]);

            }

            sb.append("}");
            System.out.println(sb.toString());

        }
 
        System.out.println("High-Interaction Zones: " + highInteractionCount);

    }
 
    private static void dfs1(Digraph g, int v, boolean[] visited, Stack<Integer> finishOrder) {
 
        visited[v] = true;

        for (int w : g.adj(v)) {

            if (!visited[w]) {

                dfs1(g, w, visited, finishOrder);

            }
        }

        finishOrder.push(v);
    }
 
    private static void dfs2(Digraph g, int v, boolean[] visited, List<Integer> scc) {
 
        visited[v] = true;
        scc.add(v);

        for (int w : g.adj(v)) {

            if (!visited[w]) {

                dfs2(g, w, visited, scc);
                
            }
        }
    }
}