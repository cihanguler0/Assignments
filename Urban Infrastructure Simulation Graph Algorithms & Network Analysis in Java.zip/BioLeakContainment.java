import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class BioLeakContainment {

    public static List<Integer> dfsReachable(Digraph g, int source, String[] labels) {

        List<Integer> reachable = new ArrayList<>();
        boolean[] visited = new boolean[g.V()];
        dfs(g, source, visited, reachable);
        
        System.out.printf("%n=== Part D, Task 1 %s(%d) ===%n", labels[source], source);
        System.out.printf("Stations at risk (%d):%n", reachable.size());

        for (int v : reachable) {

            System.out.printf("  %s(%d)%n", labels[v], v);

        }
        
        return reachable;

    }

    private static void dfs(Digraph g, int v, boolean[] visited, List<Integer> reachable) {

        visited[v] = true;
        reachable.add(v);

        for (int w : g.adj(v)) {

            if (!visited[w]) {

                dfs(g, w, visited, reachable);

            }
        }
    }

    public static List<List<Integer>> bfsLayers(Digraph g, int source, String[] labels) {

        List<List<Integer>> layers = new ArrayList<>();
        int[] distTo = new int[g.V()];
        boolean[] visited = new boolean[g.V()];

        for (int i = 0; i < g.V(); i++) 
            distTo[i] = -1;

        Queue<Integer> queue = new LinkedList<>();
        visited[source] = true;
        distTo[source] = 0;
        queue.add(source);
        int maxDist = 0;

        while (!queue.isEmpty()) {

            int v = queue.poll();
            int d = distTo[v];
            
            while (layers.size() <= d) {

                layers.add(new ArrayList<>());

            }

            layers.get(d).add(v);

            if (d > maxDist)
                 maxDist = d;

            for (int w : g.adj(v)) {

                if (!visited[w]) {

                    visited[w] = true;
                    distTo[w] = d + 1;
                    queue.add(w);

                }
            }
        }

        System.out.printf("%n=== Part D, Task 2 %s(%d) ===%n", labels[source], source);
        System.out.println("Evacuation priority layers:");

        for (int i = 0; i < layers.size(); i++) {

            String layerLabel = (i == 0) ? "Layer 0 (source)    " : "Layer " + i + " (priority " + i + ")";
            System.out.print("  " + layerLabel + " : ");

            List<Integer> currentLayer = layers.get(i);

            for (int j = 0; j < currentLayer.size(); j++) {

                int v = currentLayer.get(j);

                System.out.print(labels[v] + "(" + v + ")");

                if (j < currentLayer.size() - 1) 

                    System.out.print(", ");

            }

            System.out.println();

        }

        return layers;
        
    }
}
