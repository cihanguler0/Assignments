import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PowerGrid {

    public static boolean isConnected(Graph g) {

        if (g.V() == 0) 
            return true;

        boolean[] visited = new boolean[g.V()];
        dfs(g, 0, visited);

        for (boolean v : visited) {

            if (!v) return false;

        }

        return true;
    }

    private static void dfs(Graph g, int v, boolean[] visited) {

        visited[v] = true;
        for (Edge e : g.adj(v)) {

            int w = e.other(v);

            if (!visited[w]) {
                dfs(g, w, visited);

            }
        }
    }

    public static List<Edge> kruskalMST(Graph g) {

        List<Edge> mst = new ArrayList<>();
        List<Edge> allEdges = new ArrayList<>();
        
        for (int v = 0; v < g.V(); v++) {

            for (Edge e : g.adj(v)) {

                if (e.other(v) > v) {

                    allEdges.add(e);

                }
            }
        }

        Collections.sort(allEdges);
        int[] parent = new int[g.V()];

        for (int i = 0; i < g.V(); i++) parent[i] = i;

        for (Edge e : allEdges) {

            int v = e.either();
            int w = e.other(v);
            int rootV = find(parent, v);
            int rootW = find(parent, w);

            if (rootV != rootW) {

                mst.add(e);
                parent[rootV] = rootW;

            }
        }

        return mst;
    }

    private static int find(int[] parent, int i) {

        if (parent[i] == i) 
            return i;

        return parent[i] = find(parent, parent[i]);
        
    }
}