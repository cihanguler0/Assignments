import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
 
/**
 * AetheriaCity – Main entry point.
 *
 * Parse AetheriaCity.xml, build the required graphs, and call your
 * implementations in sequence.
 *
 * Usage:
 *   javac *.java -d .
 *   java AetheriaCity <AetheriaCity>
 */
public class AetheriaCity {
 
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.println("Usage: java AetheriaCity <xml-file>");
            return;
        }
        Document doc = parseXML(args[0]);
 
        printBanner("AETHERIA CITY – Full System Boot Report");
 
        // TODO: Parse <districts>, build Graph, call PowerGrid
 
        printBanner("PART A  |  Power Grid");
 
        NodeList districtNodes = doc.getElementsByTagName("district");
        int districtCount = districtNodes.getLength();
        Map<String, Integer> districtIndex = new HashMap<>();
        String[] districtLabels = new String[districtCount];
 
        for (int i = 0; i < districtCount; i++) {
 
            Element d = (Element) districtNodes.item(i);
            String rawId = getText(d, "id");  
            String name  = getText(d, "name"); 
            districtIndex.put(rawId, i);
            districtLabels[i] = name;
 
        }
 
        Graph powerGraph = new Graph(districtCount);
 
        for (int i = 0; i < districtCount; i++) {
 
            Element d = (Element) districtNodes.item(i);
            String rawId = getText(d, "id");
            int v = districtIndex.get(rawId);
            NodeList links = d.getElementsByTagName("link");
 
            for (int j = 0; j < links.getLength(); j++) {
 
                Element link = (Element) links.item(j);
                String targetId  = getText(link, "target");
                double cableCost = Double.parseDouble(getText(link, "cableCost"));
                int w = districtIndex.get(targetId);
 
                if (v < w) {
 
                    powerGraph.addEdge(new Edge(v, w, cableCost));
 
                }
            }
        }
 
        boolean connected = PowerGrid.isConnected(powerGraph);
        System.out.println("City fully connected? " + (connected ? "YES" : "NO"));
        List<Edge> mst = PowerGrid.kruskalMST(powerGraph);
        System.out.println("\nMinimum Spanning Tree (" + mst.size() + " cables):");
        double totalCost = 0;
 
        for (Edge e : mst) {
 
            int v = e.either();
            int w = e.other(v);
            System.out.printf("  %-22s ↔ %-22s cost: %.0f%n",districtLabels[v], districtLabels[w], e.weight());
            totalCost += e.weight();
 
        }
 
        System.out.printf("Total minimum cable cost: %.0f units%n", totalCost);
 
        // TODO: Parse <bootDependencies>, build Digraph, call BootSequence
 
        printBanner("PART B  |  Master Boot Sequence (valid order)");
 
        NodeList serviceNodes = doc.getElementsByTagName("s");
        int serviceCount = serviceNodes.getLength();
        Map<String, Integer> serviceIndex = new HashMap<>();
        String[] serviceLabels = new String[serviceCount];
 
        for (int i = 0; i < serviceCount; i++) {
 
            Element s = (Element) serviceNodes.item(i);
            String rawId = getText(s, "id");   // "S0", "S1", ...
            String name  = getText(s, "name");
            serviceIndex.put(rawId, i);
            serviceLabels[i] = name;
 
        }
 
        Digraph bootGraph = new Digraph(serviceCount);
 
        for (int i = 0; i < serviceCount; i++) {
 
            Element s = (Element) serviceNodes.item(i);
            String rawId = getText(s, "id");
            int w = serviceIndex.get(rawId);
            NodeList reqs = s.getElementsByTagName("req");
 
            for (int j = 0; j < reqs.getLength(); j++) {
 
                String reqId = reqs.item(j).getTextContent().trim();
                int v = serviceIndex.get(reqId);
                bootGraph.addEdge(v, w);
 
            }
        }
 
        BootSequence.computeBootSequence(bootGraph, serviceLabels);
 
        // TODO: Parse <fiberLinks>, build Digraph, call CommHubs
 
        printBanner("PART C  |  Secure Communication Hubs (SCCs)");
 
        NodeList stationNodes = doc.getElementsByTagName("station");
        int stationCount = stationNodes.getLength();
        Map<String, Integer> stationIndex = new HashMap<>();
        String[] stationLabels = new String[stationCount];
 
        for (int i = 0; i < stationCount; i++) {
 
            Element st = (Element) stationNodes.item(i);
            String rawId = getText(st, "id");  
            String name  = getText(st, "name");
            stationIndex.put(rawId, i);
            stationLabels[i] = name;
 
        }
 
        Digraph fiberGraph = new Digraph(stationCount);
 
        for (int i = 0; i < stationCount; i++) {
 
            Element st = (Element) stationNodes.item(i);
            String rawId = getText(st, "id");
            int v = stationIndex.get(rawId);
            NodeList outLinks = st.getElementsByTagName("link");
 
            for (int j = 0; j < outLinks.getLength(); j++) {
 
                Element link = (Element) outLinks.item(j);
                String targetId = getText(link, "target");
                int w = stationIndex.get(targetId);
                fiberGraph.addEdge(v, w);
 
            }
        }
 
        CommHubs.findHighInteractionZones(fiberGraph, stationLabels);
 
        // TODO: Parse <leakScenarios>, call BioLeakContainment
 
        printBanner("PART D  |  Bio-Leak Containment Protocol");
        NodeList scenarios = doc.getElementsByTagName("scenario");
 
        for (int i = 0; i < scenarios.getLength(); i++) {
 
            Element scenario = (Element) scenarios.item(i);
            String sourceId = getText(scenario, "sourceId"); 
            int source = stationIndex.get(sourceId);
            System.out.println("Leak origin: " + stationLabels[source] + " (id=" + source + ")");
 
            BioLeakContainment.dfsReachable(fiberGraph, source, stationLabels);
            BioLeakContainment.bfsLayers(fiberGraph, source, stationLabels);
            
        }
    }
 
    // ── XML helpers ──────────────────────────────────────────────────
 
    private static Document parseXML(String filename) throws Exception {
        File file = new File(filename + ".xml");
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(file);
        doc.getDocumentElement().normalize();
        return doc;
    }
 
    static String getText(Element parent, String tag) {
        NodeList nl = parent.getElementsByTagName(tag);
        if (nl.getLength() == 0) return "";
        return nl.item(0).getTextContent().trim();
    }
 
    static void printBanner(String title) {
        String line = "═".repeat(60);
        System.out.println("\n" + line);
        System.out.println("  " + title);
        System.out.println(line);
    }
}
