import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Grades {
    private String grade;
    private String id;
    private String course;

    public Grades(String grade, String id, String course) {
        this.grade = grade;
        this.id = id;
        this.course = course;
    }

    public String getGrade() {
        return grade;
    }

    public String getId() {
        return id;
    }
    public String getCourse() {
        return course;
    }

    public static List<Grades> readTxt(String input) {
        List<Grades> grades = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(input))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                Grades g = new Grades(parts[0], parts[1], parts[2]);
                grades.add(g);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return grades;
    }
}


