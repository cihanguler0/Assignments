import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Programs {
    private String code;
    private String name;
    private String program;
    private String department;
    private String degree;
    private String credit;

    public Programs(String code, String name, String program, String department, String degree, String credit) {
        this.code = code;
        this.name = name;
        this.program = program;
        this.department = department;
        this.degree = degree;
        this.credit = credit;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public String getDegree() {
        return degree;
    }

    public String getCredit() {
        return credit;
    }

    public static List<Programs> readTxt(String input) {
        List<Programs> programs = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(input))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                Programs p = new Programs(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]);
                programs.add(p);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return programs;
    }
}




