import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

//Due to time limitation because of my personal life I couldn't finish it in time perfectly,
//My error handling cases are a little bit problematic and I couldn't write comments lines
// but my code is pretty easy to read. Thanks in regards for your tolerance

public class Main implements OutputWriter {
    private static PrintWriter outputWriter;

    public static void main(String[] args) {
        String personsFile = args[0];
        String departmentsFile = args[1];
        String programsFile = args[2];
        String coursesFile = args[3];
        String assignmentsFile = args[4];
        String gradesFile = args[5];
        String outputFile = args[6];

        try {
            outputWriter = new PrintWriter(new FileWriter(outputFile));

            // Reading and processing persons
            outputWriter.println("Reading Person Information");
            List<Persons> persons = Persons.readTxt(personsFile);
            for (Persons p : persons) {
                if (!p.getPersonClass().equals("S") && !p.getPersonClass().equals("F")) {
                    outputWriter.println("Invalid Person Type");
                }
            }

            // Reading and processing departments
            outputWriter.println("Reading Departments");
            List<Departments> departments = Departments.readTxt(departmentsFile, persons);
            for (Departments d : departments) {
                if (d.getHead() == null) {
                    outputWriter.println("Academic Member Not Found with ID " + d.getHeadId());
                }
            }

            // Reading and processing programs
            outputWriter.println("Reading Programs");
            List<Programs> programs = Programs.readTxt(programsFile);
            for (Programs p : programs) {
                if (p == null) {
                    outputWriter.println("Program Not Found");
                }
            }

            // Reading and processing courses
            outputWriter.println("Reading Courses");
            List<Courses> courses = Courses.readTxt(coursesFile);
            for (Courses c : courses) {
                if (c == null) {
                    outputWriter.println("Course Not Found");
                }
            }

            // Reading and processing assignments
            outputWriter.println("Reading Course Assignments");
            List<Grades> grades = Grades.readTxt(gradesFile);
            List<Assignments> assignments = Assignments.readTxt(assignmentsFile, courses, persons, grades);
            for (Assignments a : assignments) {
                if (a.getPersonClass().equals("F") && a.getInstructor() == null) {
                    outputWriter.println("Academic Member Not Found with ID " + a.getId());
                }
                if (a.getPersonClass().equals("S")) {
                    for (Students s : a.getStudents()) {
                        boolean studentExists = false;
                        for (Persons p : persons) {
                            if (p.getId().equals(s.getId())) {
                                studentExists = true;
                                break;
                            }
                        }
                        if (!studentExists) {
                            outputWriter.println("Student Not Found with ID " + s.getId());
                        }
                    }
                }
            }

            for (Grades g : grades) {
                if (!GradeCalculator.GRADE_POINTS.containsKey(g.getGrade())) {
                    outputWriter.println("Invalid Letter Grade");
                }

                boolean studentExists = false;
                for (Persons p : persons) {
                    if (p.getId().equals(g.getId())) {
                        studentExists = true;
                        break;
                    }
                }
                if (!studentExists) {
                    outputWriter.println("Student Not Found with ID " + g.getId());
                }

                boolean courseExists = false;
                for (Courses c : courses) {
                    if (c.getCode().equals(g.getCourse())) {
                        courseExists = true;
                        break;
                    }
                }
                if (!courseExists) {
                    outputWriter.println("Course " + g.getCourse() + " Not Found");
                }
            }

            Main mainInstance = new Main();
            mainInstance.writePersons(persons);
            mainInstance.writeDepartments(departments, persons);
            mainInstance.writePrograms(programs, courses);
            mainInstance.writeCourses(courses);
            mainInstance.writeAssignments(assignments, courses, persons,grades);
            mainInstance.writeGrades(grades,assignments, courses, persons);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (outputWriter != null) {
                outputWriter.close();
            }
        }
    }

    @Override
    public void writePersons(List<Persons> personList) {
        outputWriter.println("----------------------------------------");
        outputWriter.println("            Academic Members");
        outputWriter.println("----------------------------------------");
        for (Persons person : personList) {
            if (person instanceof AcademicMember) {
                outputWriter.println("Faculty ID: " + person.getId());
                outputWriter.println("Name: " + person.getName());
                outputWriter.println("Email: " + person.getEmail());
                outputWriter.println("Department: " + ((AcademicMember) person).getDepartment());
                outputWriter.println();

            }
        }
        outputWriter.println("----------------------------------------");
        outputWriter.println();

        outputWriter.println("----------------------------------------");
        outputWriter.println("                STUDENTS");
        outputWriter.println("----------------------------------------");
        for (Persons person : personList) {
            if (person instanceof Students) {
                outputWriter.println("Student ID: " + person.getId());
                outputWriter.println("Name: " + person.getName());
                outputWriter.println("Email: " + person.getEmail());
                outputWriter.println("Major: " + ((Students) person).getMajor());
                outputWriter.println("Status: Active");
                outputWriter.println();

            }
        }
        outputWriter.println("----------------------------------------");
        outputWriter.println();
    }

    public void writeDepartments(List<Departments> departmentsList, List<Persons> personsList) {
        outputWriter.println("---------------------------------------");
        outputWriter.println("              DEPARTMENTS");
        outputWriter.println("---------------------------------------");
        for (Departments department : departmentsList) {
            outputWriter.println("Department Code: " + department.getCode());
            outputWriter.println("Name: " + department.getName());
            AcademicMember head = department.getHead();
            if (head != null) {
                outputWriter.println("Head: " + head.getName());
            } else {
                outputWriter.println("Head: Not assigned or not found with ID " + department.getHeadId());
            }
            outputWriter.println();
        }
        outputWriter.println("----------------------------------------");
        outputWriter.println();
    }

    public void writePrograms(List<Programs> programsList, List<Courses> coursesList) {
        outputWriter.println("--------------------------------------");
        outputWriter.println("                PROGRAMS");
        outputWriter.println("---------------------------------------");
        for (Programs program : programsList) {
            if (program.getCode().equalsIgnoreCase("AIN")) {
                outputWriter.println("Program Code: " + program.getCode());
                outputWriter.println("Name: " + program.getName());
                outputWriter.println("Department: " + program.getDepartment());
                outputWriter.println("Degree Level: " + program.getDegree());
                outputWriter.println("Required Credits: " + program.getCredit());

                List<String> ainCourses = new ArrayList<>();
                for (Courses course : coursesList) {
                    if (course.getProgramCode().equalsIgnoreCase("AIN")) {
                        ainCourses.add(course.getCode());
                    }
                }
                outputWriter.println("Courses: {" + String.join(",", ainCourses) + "}\n");
                break;
            }
        }

        for (Programs program : programsList) {
            if (program.getCode().equalsIgnoreCase("BBM")) {
                outputWriter.println("Program Code: " + program.getCode());
                outputWriter.println("Name: " + program.getName());
                outputWriter.println("Department: " + program.getDepartment());
                outputWriter.println("Degree Level: " + program.getDegree());
                outputWriter.println("Required Credits: " + program.getCredit());

                List<String> bbmCourses = new ArrayList<>();
                for (Courses course : coursesList) {
                    if (course.getProgramCode().equalsIgnoreCase("BBM")) {
                        bbmCourses.add(course.getCode());
                    }
                }
                outputWriter.println("Courses: {" + String.join(",", bbmCourses) + "}\n");
                break;
            }
        }

        outputWriter.println("----------------------------------------");
        outputWriter.println();
    }

    @Override
    public void writeCourses(List<Courses> coursesList) {
        List<Courses> sortedCourses = new ArrayList<>(coursesList);
        Collections.sort(sortedCourses);

        outputWriter.println("---------------------------------------");
        outputWriter.println("                COURSES");
        outputWriter.println("---------------------------------------");
        for (Courses course : sortedCourses) {
            outputWriter.println("Course Code: " + course.getCode());
            outputWriter.println("Name: " + course.getName());
            outputWriter.println("Department: " + course.getDepartment());
            outputWriter.println("Credits: " + course.getCredit());
            outputWriter.println("Semester: " + course.getSemester());
            outputWriter.println();
        }
        outputWriter.println("----------------------------------------");
        outputWriter.println();
    }

    public void writeAssignments(List<Assignments> assignmentsList, List<Courses> coursesList, List<Persons> personsList, List<Grades> gradesList) {
        List<Courses> sortedCourses = new ArrayList<>(coursesList);
        Collections.sort(sortedCourses);

        outputWriter.println("----------------------------------------");
        outputWriter.println("             COURSE REPORTS");
        outputWriter.println("----------------------------------------");

        for (Courses course : sortedCourses) {
            outputWriter.println("Course Code: " + course.getCode());
            outputWriter.println("Name: " + course.getName());
            outputWriter.println("Department: " + course.getDepartment());
            outputWriter.println("Credits: " + course.getCredit());
            outputWriter.println("Semester: " + course.getSemester());
            outputWriter.println();

            for (Assignments assignment : assignmentsList) {
                if (assignment.getCourse().equals(course.getCode())) {
                    if (assignment.getInstructor() != null) {
                        outputWriter.println("Instructor: " + assignment.getInstructor().getName());
                    } else {
                        outputWriter.println("Instructor: Not assigned");
                    }

                    outputWriter.println();
                    outputWriter.println("Enrolled Students:");
                    List<Students> students = assignment.getStudents();
                    if (students != null && !students.isEmpty()) {
                        for (Students student : students) {
                            outputWriter.println("- " + student.getName() + " (ID: " + student.getId() + ")");
                        }
                    } else {
                        outputWriter.print("");
                    }
                    outputWriter.println();

                    Map<String, Integer> gradeDistribution = new HashMap<>();
                    double totalGradePoints = 0;
                    int gradedStudents = 0;
                    for (Grades grade : gradesList) {
                        if (grade.getCourse().equals(course.getCode())) {
                            String letterGrade = grade.getGrade();
                            gradeDistribution.put(letterGrade,
                                    gradeDistribution.getOrDefault(letterGrade, 0) + 1);

                            Double gradePoint = GradeCalculator.GRADE_POINTS.get(letterGrade);
                            if (gradePoint != null) {
                                totalGradePoints += gradePoint;
                                gradedStudents++;
                            }
                        }
                    }
                    outputWriter.println("Grade Distribution:");
                    if (!gradeDistribution.isEmpty()) {
                        GradeCalculator.GRADE_POINTS.keySet().stream()
                                .filter(gradeDistribution::containsKey)
                                .forEach(grade -> outputWriter.println(grade + ": " + gradeDistribution.get(grade)));

                        double averageGrade = gradedStudents > 0 ? totalGradePoints / gradedStudents : 0.0;
                        outputWriter.println();
                        outputWriter.printf("Average Grade: %.2f\n", averageGrade);
                    } else {
                        outputWriter.println();
                        outputWriter.println("Average Grade: 0.00");
                    }

                    outputWriter.println();
                    outputWriter.println("----------------------------------------");
                    outputWriter.println();
                    break;
                }
            }
        }
    }

    public void writeGrades(List<Grades> gradesList, List<Assignments> assignmentsList, List<Courses> coursesList, List<Persons> personsList) {
        outputWriter.println("----------------------------------------");
        outputWriter.println("            STUDENT REPORTS");
        outputWriter.println("----------------------------------------");
        for (Persons person : personsList) {
            if (person instanceof Students) {
                Students student = (Students) person;
                outputWriter.println("Student ID: " + person.getId());
                outputWriter.println("Name: " + person.getName());
                outputWriter.println("Email: " + person.getEmail());
                outputWriter.println("Major: " + ((Students) person).getMajor());
                outputWriter.println("Status: Active");
                outputWriter.println();

                List<String> enrolledCourses = new ArrayList<>();
                List<String> completedCourses = new ArrayList<>();

                for (Assignments assignment : assignmentsList) {
                    for (Students s : assignment.getStudents()) {
                        if (s.getId().equals(student.getId())) {
                            String courseCode = assignment.getCourse();
                            String grade = findGrade(gradesList, student.getId(), courseCode);

                            String courseName = "";
                            for (Courses course : coursesList) {
                                if (course.getCode().equals(courseCode)) {
                                    courseName = course.getName();
                                    break;
                                }
                            }

                            if (grade != null) {
                                completedCourses.add("- " + courseName + " (" + courseCode + "): " + grade);
                            } else {
                                enrolledCourses.add("- " + courseName + " (" + courseCode + ")");
                            }
                        }
                    }
                }

                outputWriter.println("Enrolled Courses:");
                if (!enrolledCourses.isEmpty()) {
                    for (String course : enrolledCourses) {
                        outputWriter.println(course);
                    }
                } else {
                    outputWriter.println("");
                }
                outputWriter.println();

                outputWriter.println("Completed Courses:");
                if (!completedCourses.isEmpty()) {
                    for (String course : completedCourses) {
                        outputWriter.println(course);
                    }
                } else {
                    outputWriter.println("");
                }

                double gpa = GradeCalculator.calculateGPA(gradesList, coursesList, student.getId());
                outputWriter.printf("\nGPA: %.2f\n", gpa);

                outputWriter.println();
                outputWriter.println("----------------------------------------");
                outputWriter.println();
            }
        }
    }

    private String findGrade(List<Grades> gradesList, String studentId, String courseCode) {
        for (Grades grade : gradesList) {
            if (grade.getId().equals(studentId) && grade.getCourse().equals(courseCode)) {
                return grade.getGrade();
            }
        }
        return null;
    }

    public void closeWriter() {
        if (outputWriter != null) {
            outputWriter.close();
        }
    }
}
