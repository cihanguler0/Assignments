import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Assignments {
    private String personClass;
    private String id;
    private String course;
    private AcademicMember instructor;
    private List<Students> students;

    public Assignments(String personClass, String id, String course) {
        this.personClass = personClass;
        this.id = id;
        this.course = course;
        this.students = new ArrayList<>();
    }

    public String getPersonClass() {
        return personClass;
    }

    public String getId() {
        return id;
    }

    public String getCourse() {
        return course;
    }

    public AcademicMember getInstructor() {
        return instructor;
    }

    public List<Students> getStudents() {
        return students;
    }

    public void setInstructor(AcademicMember instructor) {
        this.instructor = instructor;
    }

    public void addStudent(Students student) {
        this.students.add(student);
    }

    public static List<Assignments> readTxt(String input, List<Courses> courseList, List<Persons> personList, List<Grades> gradesList) {
        List<Assignments> assignments = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(input))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String personClass = parts[0];
                String id = parts[1];
                String courseCode = parts[2];

                Assignments existingAssignment = null;
                for (Assignments a : assignments) {
                    if (a.getCourse().equals(courseCode)) {
                        existingAssignment = a;
                        break;
                    }
                }

                if (existingAssignment == null) {
                    existingAssignment = new Assignments(personClass, id, courseCode);
                    assignments.add(existingAssignment);
                }

                if (personClass.equals("F")) {
                    boolean found = false;
                    for (Persons person : personList) {
                        if (person.getId().equals(id) && person instanceof AcademicMember) {
                            existingAssignment.setInstructor((AcademicMember) person);
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        System.err.println("Warning: Instructor with ID " + id + " not found in person list!");
                    }
                }

                else if (personClass.equals("S")) {
                    for (Persons person : personList) {
                        if (person.getId().equals(id) && person instanceof Students) {
                            existingAssignment.addStudent((Students) person);
                            break;
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return assignments;
    }
}






