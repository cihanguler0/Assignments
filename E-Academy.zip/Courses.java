import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Courses implements Comparable<Courses> {
    private String code;
    private String name;
    private String department;
    private int credit;
    private String semester;
    private String programCode;

    public Courses(String code, String name, String department, int credit, String semester, String programCode) {
        this.code = code;
        this.name = name;
        this.department = department;
        this.credit = credit;
        this.semester = semester;
        this.programCode = programCode.toLowerCase();
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public int getCredit() {
        return credit;
    }

    public String getSemester() {
        return semester;
    }

    public int compareTo(Courses other) {
        return this.code.compareTo(other.code);
    }

    public String getProgramCode() {
        return programCode;
    }

    public static List<Courses> readTxt(String input) {
        List<Courses> courses = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(input))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6) {
                    int credit = Integer.parseInt(parts[3].trim());
                    String programCode = parts[5].trim().toLowerCase();

                    if (programCode.equals("ain")) {
                        courses.add(new AIN(parts[0], parts[1], parts[2], credit, parts[4], programCode));
                    } else if (programCode.equals("bbm")) {
                        courses.add(new BBM(parts[0], parts[1], parts[2], credit, parts[4], programCode));
                    }
                }
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
        return courses;
    }
}

class AIN extends Courses {
    public AIN(String code, String name, String department, int credit, String semester, String programCode) {
        super(code, name, department, credit, semester, programCode);
    }
}

class BBM extends Courses {
    public BBM(String code, String name, String department, int credit, String semester, String programCode) {
        super(code, name, department, credit, semester, programCode);
    }
}





