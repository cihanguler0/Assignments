import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class GradeCalculator {
    public static final Map<String, Double> GRADE_POINTS = new LinkedHashMap<>();

    static {
        GRADE_POINTS.put("A1", 4.00);
        GRADE_POINTS.put("A2", 3.50);
        GRADE_POINTS.put("B1", 3.00);
        GRADE_POINTS.put("B2", 2.50);
        GRADE_POINTS.put("C1", 2.00);
        GRADE_POINTS.put("C2", 1.50);
        GRADE_POINTS.put("D1", 1.00);
        GRADE_POINTS.put("D2", 0.50);
        GRADE_POINTS.put("F3", 0.00);
    }

    public static double calculateGPA(List<Grades> gradesList,
                                      List<Courses> coursesList,
                                      String studentId) {
        double totalPoints = 0.0;
        int totalCredits = 0;

        for (Grades grade : gradesList) {
            if (grade.getId().equals(studentId)) {
                int credit = 0;
                for (Courses course : coursesList) {
                    if (course.getCode().equals(grade.getCourse())) {
                        credit = (int) course.getCredit();
                        break;
                    }
                }

                Double points = GRADE_POINTS.get(grade.getGrade());
                if (points != null && credit > 0) {
                    totalPoints += points * credit;
                    totalCredits += credit;
                }
            }
        }

        return totalCredits > 0 ? totalPoints / totalCredits : 0.0;
    }
}
