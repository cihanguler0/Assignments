import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Departments {
    private String code;
    private String name;
    private String department;
    private String headId;
    private AcademicMember head;

    public Departments(String code, String name, String department, String headId) {
        this.code = code;
        this.name = name;
        this.department = department;
        this.headId = headId;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getHeadId() {
        return headId;
    }

    public AcademicMember getHead() {
        return head;
    }

    public void assignHead(List<Persons> personList) {
        if (headId == null) return;
        for (Persons person : personList) {
            if (person instanceof AcademicMember) {
                if (person.getId() != null && person.getId().trim().equals(headId)) {
                    this.head = (AcademicMember) person;
                    break;
                }
            }
        }
    }

    public static List<Departments> readTxt(String input, List<Persons> personList) {
        List<Departments> departments = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(input))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                Departments dept = new Departments(parts[0], parts[1], parts[2], parts[3]);
                dept.assignHead(personList);
                departments.add(dept);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return departments;
    }
}



