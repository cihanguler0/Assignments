import java.util.List;

public interface OutputWriter {
    void writePersons(List<Persons> personList);
    void writeDepartments(List<Departments> departmentsList, List<Persons> personsList);
    void writePrograms(List<Programs> programsList, List<Courses> coursesList);
    void writeCourses(List<Courses> coursesList);
    void writeAssignments(List<Assignments> assignmentsList,List<Courses> courseList, List<Persons> personsList, List<Grades> gradesList);
    void writeGrades(List<Grades> gradesList, List<Assignments> assignmentsList, List<Courses> courseList, List<Persons> personsList);
    void closeWriter();
}