import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

abstract class Persons {
    private String personClass;
    private String id;
    private String name;
    private String email;

    public Persons(String personClass, String id, String name, String email) {
        this.personClass = personClass;
        this.id = id;
        this.name = name;
        this.email = email;
    }

    public String getPersonClass() {
        return personClass;
    }
    public String getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public String getEmail() {
        return email;
    }

    public static List<Persons> readTxt(String input){
        List<Persons> personList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(input))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals("S")) {
                    Students student = new Students(parts[0], parts[1], parts[2], parts[3], parts[4]);
                    personList.add(student);
                } else if (parts[0].equals("F")) {
                    AcademicMember member = new AcademicMember(parts[0], parts[1], parts[2], parts[3], parts[4]);
                    personList.add(member);
                } else {
                    personList.add(new InvalidPerson(parts[0], parts[1], parts[2], parts[3]));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return personList;
    }
}

class Students extends Persons {
    private String major;

    public Students(String personClass, String id, String name, String email, String major) {
        super(personClass, id, name, email);
        this.major = major;
    }

    public String getMajor() {
        return major;
    }
}

class AcademicMember extends Persons {
    private String department;

    public AcademicMember(String personClass, String id, String name, String email, String department) {
        super(personClass, id, name, email);
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }
}

class InvalidPerson extends Persons {
    public InvalidPerson(String personClass, String id, String name, String email) {
        super(personClass, id, name, email);
    }
}
