import java.util.*;
import java.util.regex.*;

public class SpaceportTransitNetwork {

    double shuttleSpeed;
    final double walkSpeed = 1000 / 6.0;

    Station start, end;
    List<ShuttleCorridor> corridors;

    String content;

    int getInt(String v) {
        Pattern p = Pattern.compile(v + "\\s*=\\s*([0-9]+)");
        Matcher m = p.matcher(content);
        m.find();
        return Integer.parseInt(m.group(1));
    }

    double getDouble(String v) {

        Pattern p = Pattern.compile(v + "\\s*=\\s*([0-9]+\\.?[0-9]*)");
        Matcher m = p.matcher(content);

        if (m.find()) {

            return Double.parseDouble(m.group(1));

        }

        return 0;

    }

    Point getPoint(String v) {

        Pattern p = Pattern.compile(v + "\\s*=\\s*\\(\\s*([0-9]+)\\s*,\\s*([0-9]+)\\s*\\)");
        Matcher m = p.matcher(content);

        if (m.find()) {

            return new Point(Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)));

        }

        return null;

    }

    List<ShuttleCorridor> parseCorridors() {
        List<ShuttleCorridor> list = new ArrayList<>();

        Pattern corridorPattern = Pattern.compile("corridor_name\\s*=\\s*\"([^\"]+)\"\\s*corridor_stations\\s*=\\s*([\\(\\s0-9,)]+)");
        Matcher m = corridorPattern.matcher(content);

        while (m.find()) {

            String name = m.group(1);
            String stationsStr = m.group(2);
            List<Station> stations = new ArrayList<>();
            Pattern pointPattern = Pattern.compile("\\(\\s*([0-9]+)\\s*,\\s*([0-9]+)\\s*\\)");
            Matcher pm = pointPattern.matcher(stationsStr);
            int count = 1;

            while (pm.find()) {

                Point p = new Point(Integer.parseInt(pm.group(1)), Integer.parseInt(pm.group(2)));
                stations.add(new Station(p, name + " Station " + count++));

            }

            list.add(new ShuttleCorridor(name, stations));

        }

        return list;
    }

    void readInput(String f) {

        try {

            content = new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(f)));

        } catch (Exception e) { e.printStackTrace(); }
    
        double rawSpeed = getDouble("average_shuttle_speed");
        this.shuttleSpeed = (rawSpeed * 1000.0) / 60.0;
        start = new Station(getPoint("origin_point"), "Origin Point");
        end = new Station(getPoint("destination_point"), "Destination Point");
        corridors = parseCorridors();
        
    }
}