import java.util.*;

public class LaunchPlan {

    String name;
    List<Operation> ops;

    public LaunchPlan(String n, List<Operation> o) {
        name = n;
        ops = o;
    }

    /**
     * Computes the earliest possible start times for all operations.
     * You should consider dependency constraints between operations.
     */
    public int[] earliest() {

        int maxCode = 0;

        for (Operation op : ops) {

            if (op.code > maxCode) {

                maxCode = op.code;

            }

        }

        int[] startTimes = new int[maxCode + 1];
        int[] inDegree = new int[maxCode + 1];
        Map<Integer, Operation> byCode = new HashMap<>();
        Map<Integer, List<Integer>> nextOps = new HashMap<>();

        for (Operation op : ops) {

            byCode.put(op.code, op);
            inDegree[op.code] = op.prereq.size();
            nextOps.putIfAbsent(op.code, new ArrayList<>());

        }

        for (Operation op : ops) {

            for (int pre : op.prereq) {

                nextOps.putIfAbsent(pre, new ArrayList<>());
                nextOps.get(pre).add(op.code);

            }
        }

        Queue<Integer> queue = new LinkedList<>();

        for (Operation op : ops) {

            if (inDegree[op.code] == 0) {

                queue.add(op.code);

            }
        }

        List<Integer> topoOrder = new ArrayList<>();

        while (!queue.isEmpty()) {

            int currentCode = queue.poll();
            topoOrder.add(currentCode);
            Operation currentOp = byCode.get(currentCode);
            int finishTime = startTimes[currentCode] + currentOp.time;

            if (nextOps.containsKey(currentCode)) {

                for (int neighborCode : nextOps.get(currentCode)) {
                    
                    startTimes[neighborCode] = Math.max(startTimes[neighborCode], finishTime);
                    inDegree[neighborCode]--;

                    if (inDegree[neighborCode] == 0) {

                        queue.add(neighborCode);

                    }
                }
            }
        }

        return startTimes;

    }

    /**
     * Computes total time required to complete all operations.
     */
    public int total(int[] schedule) {

        int maxFinish = 0;

        for (Operation op : ops) {

            int finish = schedule[op.code] + op.time;

            if (finish > maxFinish) {

                maxFinish = finish;

            }
        }
        
        return maxFinish;

    }

    /**
     * Helper function to print separator line
     */
    public static void printLine(int n) {
        for (int i = 0; i < n; i++) System.out.print("-");
        System.out.println();
    }

    /**
     * Prints the launch plan timeline in required format.
     */
    public void print() {

        int[] schedule = earliest();
        int readiness = total(schedule);

        int width = 65;

        printLine(width);
        System.out.println("Launch Plan: " + name);
        printLine(width);

        // Header
        System.out.printf("%-8s%-35s%-8s%-8s\n", "Code", "Operation", "Begin", "Finish");

        printLine(width);

        // TODO:
        // Print each operation with:
        // code, label, start time, finish time

        List<Operation> sorted = new ArrayList<>(ops);
        sorted.sort(Comparator.comparingInt(op -> op.code));
 
        for (Operation op : sorted) {

            int begin = schedule[op.code];
            int fin = begin + op.time;
            System.out.printf("%-8d%-35s%-8d%-8d\n", op.code, op.label, begin, fin);

        }

        printLine(width);

        // TODO:
        // Print total duration in format:
        // Launch-ready in X hour(s).

        System.out.println("Launch-ready in " + readiness + " hour(s).");

        printLine(width);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LaunchPlan)) return false;

        LaunchPlan other = (LaunchPlan) o;

        return name.equals(other.name) && ops.equals(other.ops);
    }
}