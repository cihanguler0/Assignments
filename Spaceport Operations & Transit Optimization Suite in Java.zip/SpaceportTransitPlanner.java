import java.util.*;

public class SpaceportTransitPlanner {

    Map<Station, Station> prev = new HashMap<>();
    Map<String, Double> cost = new HashMap<>();

    double dist(Station a, Station b) {
        double dx = a.p.x - b.p.x;
        double dy = a.p.y - b.p.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    void addUndirected(Station a, Station b, double speed) {

        double time = dist(a, b) / speed;
        a.edges.add(new Edge(b, time));
        b.edges.add(new Edge(a, time));

    }

    void addDirected(Station a, Station b, double speed) {

        double time = dist(a, b) / speed;
        a.edges.add(new Edge(b, time));

    }

    public List<RouteInstruction> solve(SpaceportTransitNetwork net) {
        List<RouteInstruction> route = new ArrayList<>();

        List<Station> allNodes = new ArrayList<>();
        allNodes.add(net.start);
        allNodes.add(net.end);

        for (ShuttleCorridor c : net.corridors) {

            allNodes.addAll(c.stations);

        }

        for (int i = 0; i < allNodes.size(); i++) {

            for (int j = i + 1; j < allNodes.size(); j++) {

                addUndirected(allNodes.get(i), allNodes.get(j), net.walkSpeed);

            }
        }

        for (ShuttleCorridor c : net.corridors) {

            for (int i = 0; i < c.stations.size() - 1; i++) {

                addDirected(c.stations.get(i), c.stations.get(i + 1), net.shuttleSpeed);

            }
        }

        PriorityQueue<Edge> pq = new PriorityQueue<>();
        Map<Station, Double> minTime = new HashMap<>();

        for (Station s : allNodes) {

            minTime.put(s, Double.MAX_VALUE);

        }    

        minTime.put(net.start, 0.0);
        pq.add(new Edge(net.start, 0.0));

        while (!pq.isEmpty()) {

            Edge current = pq.poll();

            if (current.w > minTime.get(current.to)) 
                continue;

            for (Edge e : current.to.edges) {

                double newTime = minTime.get(current.to) + e.w;

                if (newTime < minTime.get(e.to)) {

                    minTime.put(e.to, newTime);
                    prev.put(e.to, current.to); 
                    pq.add(new Edge(e.to, newTime));

                }
            }
        }

        Station curr = net.end;

        while (curr != net.start && prev.containsKey(curr)) {

            Station parent = prev.get(curr);
            double travelTime = 0;
            boolean isShuttle = false;

            double minW = Double.MAX_VALUE;
            for (Edge e : parent.edges) {

                if (e.to == curr && e.w < minW) {

                    minW = e.w;
                
                }
            }

            travelTime = minW;
            double dist = dist(parent, curr);
            isShuttle = Math.abs(travelTime - (dist / net.shuttleSpeed)) < 0.001;
            route.add(0, new RouteInstruction(parent.name, curr.name, travelTime, isShuttle));
            curr = parent;

        }

        return route;
    }

    public void print(List<RouteInstruction> r) {

        double totalTime = 0;

        for (RouteInstruction ri : r) {

            totalTime += ri.t;

        }

        System.out.printf("Fastest route takes %d minute(s).\n", Math.round(totalTime));
        System.out.println("Route Instructions");
        System.out.println("------------------");

        for (int i = 0; i < r.size(); i++) {

            RouteInstruction ri = r.get(i);
            String action = ri.shuttle ? "Take the shuttle from" : "Walk from";
            System.out.printf("%d. %s \"%s\" to \"%s\" for %.2f minutes.\n", (i + 1), action, ri.a, ri.b, ri.t);

        }
    }
}