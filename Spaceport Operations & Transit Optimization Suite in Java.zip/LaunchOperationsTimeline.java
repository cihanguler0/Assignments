import java.io.File;
import java.util.*;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class LaunchOperationsTimeline {

    public List<LaunchPlan> readXML(String file) {
        List<LaunchPlan> list = new ArrayList<>();
        // TODO: Parse XML and populate launch plans

        try {

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new File(file));
            doc.getDocumentElement().normalize();
            NodeList planNodes = doc.getElementsByTagName("LaunchPlan");
 
            for (int i = 0; i < planNodes.getLength(); i++) {

                Element planElement = (Element) planNodes.item(i);
                String planName = planElement.getElementsByTagName("PlanName").item(0).getTextContent().trim();
                List<Operation> ops = new ArrayList<>();
                NodeList opNodes = planElement.getElementsByTagName("Operation");
 
                for (int j = 0; j < opNodes.getLength(); j++) {

                    Element opElement = (Element) opNodes.item(j);
                    int code = Integer.parseInt(opElement.getElementsByTagName("Code").item(0).getTextContent().trim());
                    String label = opElement.getElementsByTagName("Label").item(0).getTextContent().trim();
                    int execTime = Integer.parseInt(opElement.getElementsByTagName("ExecutionTime").item(0).getTextContent().trim());
                    List<Integer> prereqs = new ArrayList<>();
                    NodeList reqNodes = opElement.getElementsByTagName("RequiresOperation");

                    for (int k = 0; k < reqNodes.getLength(); k++) {

                        prereqs.add(Integer.parseInt(reqNodes.item(k).getTextContent().trim()));

                    }
 
                    ops.add(new Operation(code, label, execTime, prereqs));

                }
 
                list.add(new LaunchPlan(planName, ops));
            }
 
        } catch (Exception e) {
            e.printStackTrace();

        }
 
        return list;
    }

    public void printTimeline(List<LaunchPlan> plans) {

        for (LaunchPlan plan : plans) {
            
            plan.print();

        }
    }
}