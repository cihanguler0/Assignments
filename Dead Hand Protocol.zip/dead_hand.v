`timescale 1s/1ms
// ============================================================
// dead_hand.v  (STUDENT STARTER CODE)
// BBM233 Logic Design Laboratory
// Final Project: World War III – Dead Hand Protocol
//
// IMPORTANT:
// - Do NOT change module name or port list.
// - clk is 1 Hz (1 tick per second).
// - reset is synchronous, active-high.
// - Implement Main FSM + Engagement Sub-FSM.
// ============================================================

module dead_hand(
    input  wire       clk,
    input  wire       reset,
    input  wire [1:0] threat_level,
    input  wire       diplomatic_override,
    input  wire       comms_lost,
    input  wire       system_fault,

    output reg        armed_out,
    output reg        tracking_out,
    output reg        authorization_out,
    output reg        override_ignored,
    output reg [2:0]  main_state_out,
    output reg [1:0]  sub_state_out,
    output reg [31:0] timer_out
);

    localparam PEACE        = 3'b000;
    localparam ALERT        = 3'b001;
    localparam MOBILIZATION = 3'b010;
    localparam ENGAGEMENT   = 3'b011;
    localparam GLOBAL_WAR   = 3'b101;
    localparam DEADLOCK     = 3'b110;

    localparam ARM       = 2'b00;
    localparam TRACK     = 2'b01;
    localparam AUTHORIZE = 2'b10;
    localparam ABORT     = 2'b11;

    reg [2:0]  main_state;
    reg [1:0]  sub_state;
    reg [31:0] main_timer;
    reg [31:0] sub_timer;

    always @(posedge clk) begin

        if (reset) begin
            main_state       <= PEACE;
            sub_state        <= ABORT;
            main_timer       <= 0;
            sub_timer        <= 0;
            override_ignored <= 0;
        end

        else if (system_fault && main_state != GLOBAL_WAR && main_state != DEADLOCK) begin
            main_state <= GLOBAL_WAR;
            sub_state  <= ABORT;
            sub_timer  <= 0;
        end

        else if (main_state == GLOBAL_WAR || main_state == DEADLOCK) begin

            if (diplomatic_override)
                override_ignored <= 1;
        end

        else begin
            case (main_state)

                PEACE: begin

                    if (threat_level >= 2'b01) begin
                        
                        if (main_timer >= 4) begin
                            main_state <= ALERT;
                            main_timer <= 0;

                        end else main_timer <= main_timer + 1;

                    end else main_timer <= 0;
                    
                end

                ALERT: begin

                    if (threat_level >= 2'b10) begin

                        if (main_timer >= 9) begin
                            main_state <= MOBILIZATION;
                            main_timer <= 0;
                        end else main_timer <= main_timer + 1;

                    end else if (threat_level == 2'b00) begin
                        if (main_timer >= 3) begin
                            main_state <= PEACE;
                            main_timer <= 0;
                        end else main_timer <= main_timer + 1;

                    end else main_timer <= 0;

                end

                MOBILIZATION: begin

                    if (threat_level == 2'b11 || comms_lost) begin
                        main_state <= ENGAGEMENT;
                        main_timer <= 0;
                        sub_state  <= ARM;
                        sub_timer  <= 0;

                    end else if (threat_level <= 2'b01) begin

                        if (main_timer >= 3) begin
                            main_state <= ALERT;
                            main_timer <= 0;
                        end else main_timer <= main_timer + 1;
                    end else main_timer <= 0;
                end

                ENGAGEMENT: begin

                    if (diplomatic_override) begin

                        if (sub_state == AUTHORIZE && sub_timer >= 2) begin
                            override_ignored <= 1;

                        end else begin
                            sub_state <= ABORT;
                            sub_timer <= 0;
                        end
                    end

                    sub_timer <= sub_timer + 1;

                    case (sub_state)

                        ARM: begin

                            if (sub_timer >= 3) begin
                                sub_state <= TRACK;
                                sub_timer <= 0;
                            end
                        end

                        TRACK: begin

                            if (sub_timer >= 5) begin
                                sub_state <= AUTHORIZE;
                                sub_timer <= 0;
                            end

                        end

                        AUTHORIZE: begin

                            if (sub_timer >= 2) begin
                                main_state <= DEADLOCK;
                                sub_timer  <= 0;
                            end

                        end

                        ABORT: begin

                            if (sub_timer >= 4) begin 
                                main_state <= MOBILIZATION;
                                main_timer <= 0;
                                sub_timer  <= 0;

                            end
                        end
                    endcase
                end
            endcase
        end
    end

    always @(*) begin

        armed_out         = (sub_state == ARM);
        tracking_out      = (sub_state == TRACK);
        authorization_out = (sub_state == AUTHORIZE);
        main_state_out    = main_state;
        sub_state_out     = sub_state;

        if (main_state == ENGAGEMENT)
            timer_out = sub_timer;

        else
            timer_out = main_timer;
    end

endmodule
