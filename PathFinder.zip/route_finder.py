from sys import argv

def value_counter(f_in):                              #This part saves values for us.
    values = f_in.readline().split()
    first_value = values[0]
    second_value = values[1]
    third_value = values[2]
    return first_value, second_value, third_value

def value_changer(f_in, first_value, second_value, third_value):    #In this part code creates and updated matrix, because I thought this way instead of checking and adding them from a list or dict.
    lines = f_in.readlines()
    matrix = [list(map(int, line.split())) for line in lines]

    next_to = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    near = [(-1, -1), (-1, 1), (1, -1), (1, 1)]

    for r in range(len(matrix)):
        for ran in range(len(matrix[r])):
            if matrix[r][ran] == 0:
                for row, col in near:
                    nrow, ncol = r + row, ran + col
                    if 0 <= nrow < len(matrix) and 0 <= ncol < len(matrix[nrow]) and matrix[nrow][ncol] == 1:
                        matrix[nrow][ncol] = int(second_value)
                for row, col in next_to:
                    nrow, ncol = r + row, ran + col
                    if 0 <= nrow < len(matrix) and 0 <= ncol < len(matrix[nrow]) and matrix[nrow][ncol] == 1:
                        matrix[nrow][ncol] = int(third_value)

    updated_matrix = [[int(first_value) if x == 1 else x for x in m] for m in matrix]
    return updated_matrix

def go_right(updated_matrix, r, c, total, path, shortest):    #This and next four functions are for directions.
    if c + 1 < len(updated_matrix[0]) and updated_matrix[r][c + 1] != 0 and updated_matrix[r][c + 1] != 'X':  #Checking if there is a road, or is it 0 or X
        current_value = updated_matrix[r][c + 1]    #If road is suitable it moves
        updated_matrix[r][c + 1] = 'X'              #Making the point 'X' that we have just passed, so we won't go there again.
        path.append((r, c + 1))                     #Updating path
        total += current_value                      #Updating total

        if total >= shortest["total"]:                  #We check this in every step, because code should stop running and start for an another road if current total is greater than shortest. It's important for optimization.
            path.pop()
            updated_matrix[r][c + 1] = current_value
            return

        if c + 1 == len(updated_matrix[0]) - 1:        #When code reaches and rightest point, if it's shortest one it updates it.
            if total < shortest["total"]:
                shortest["total"] = total
                shortest["path"] = path[:]
        else:
            go_right(updated_matrix, r, c + 1, total, path, shortest)    #Recursion part.
            go_down(updated_matrix, r, c + 1, total, path, shortest)

        path.pop()
        updated_matrix[r][c + 1] = current_value

def go_down(updated_matrix, r, c, total, path, shortest):
    if r + 1 < len(updated_matrix) and updated_matrix[r + 1][c] != 0 and updated_matrix[r + 1][c] != 'X':
        current_value = updated_matrix[r + 1][c]
        updated_matrix[r + 1][c] = 'X'
        path.append((r + 1, c))
        total += current_value

        if total >= shortest["total"]:
            path.pop()
            updated_matrix[r + 1][c] = current_value
            return

        go_right(updated_matrix, r + 1, c, total, path, shortest)
        go_down(updated_matrix, r+1, c, total, path, shortest)
        go_up(updated_matrix, r + 1, c, total, path, shortest)

        path.pop()
        updated_matrix[r + 1][c] = current_value

def go_up(updated_matrix, r, c, total, path, shortest):
    if r - 1 >= 0 and updated_matrix[r - 1][c] != 0 and updated_matrix[r - 1][c] != 'X':
        current_value = updated_matrix[r - 1][c]
        updated_matrix[r - 1][c] = 'X'
        path.append((r - 1, c))
        total += current_value

        if total >= shortest["total"]:
            path.pop()
            updated_matrix[r - 1][c] = current_value
            return

        go_right(updated_matrix, r - 1, c, total, path, shortest)
        go_down(updated_matrix, r + 1, c, total, path, shortest)
        go_up(updated_matrix, r + 1, c, total, path, shortest)
        go_left(updated_matrix, r - 1, c, total, path, shortest)

        path.pop()
        updated_matrix[r - 1][c] = current_value

def go_left(updated_matrix, r, c, total, path, shortest):
    if c - 1 >= 0 and updated_matrix[r][c - 1] != 0 and updated_matrix[r][c - 1] != 'X':
        current_value = updated_matrix[r][c - 1]
        updated_matrix[r][c - 1] = 'X'
        path.append((r, c - 1))
        total += current_value

        if total >= shortest["total"]:
            path.pop()
            updated_matrix[r][c - 1] = current_value
            return

        path.pop()
        updated_matrix[r][c - 1] = current_value

def navigator(updated_matrix):                                 #This part is for controlling codes movement
    minimum = {"total": float('inf'), "path": []}              #Making first minimum infinite so first road will be added automatically
    for row in range(len(updated_matrix)):
        matrix_copy = [row[:] for row in updated_matrix]       #Copying our matrix for unnecessary errors.
        start = matrix_copy[row][0]                            #Starting from 0,0 point.
        if start == 0:
            continue

        matrix_copy[row][0] = 'X'                              #Making first step X
        shortest = {"total": float('inf'), "path": []}
        path = [(row, 0)]
        total = start

        go_right(matrix_copy, row, 0, total, path, shortest)
        if shortest["total"] < minimum["total"]:
            minimum = shortest                                   #Checking shortest
    return minimum["total"], minimum["path"]

def matrix_cleaner(updated_matrix, path):                                 #In this part code makes matrix like the one in the input, but adding X
    for r, c in path:
        updated_matrix[r][c] = 'X'

    for r in range(len(updated_matrix)):
        for c in range(len(updated_matrix[r])):
            if updated_matrix[r][c] != 0 and updated_matrix[r][c] != 'X':
                updated_matrix[r][c] = 1
    return updated_matrix

def main():
    f_in = open(argv[1], "r")
    first_value, second_value, third_value = value_counter(f_in)
    updated_matrix = value_changer(f_in, first_value, second_value, third_value)
    result, path = navigator(updated_matrix)
    clear_matrix = matrix_cleaner(updated_matrix, path)
    f_out = open(argv[2], "w")
    if result == float('inf'):
        f_out.write("There is no possible route!")
    else:
        f_out.write("Cost of the route: " + str(result))
        for row in clear_matrix:
            f_out.write("\n" + " ".join(map(str, row)))

if __name__ == "__main__":
    main()
