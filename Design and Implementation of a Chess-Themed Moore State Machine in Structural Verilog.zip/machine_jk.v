module machine_jk(
    input wire x,
    input wire CLK,
    input wire RESET,
    output wire F,
    output wire [2:0] S
);
    wire JA, KA, JB, KB, JC, KC;
    wire A, B, C;
    
    assign A = S[2];
    assign B = S[1];
    assign C = S[0];

    assign JA = C & (x ^ B);
    assign KA = B | (C & ~x);
    assign JB = ~C & (x ^ A);
    assign KB = A | ~C;
    assign JC = ~A | (x & ~B);
    assign KC = 1'b1;

    assign F = A & B & ~C;

    jkff jk2 (
        .J(JA),
        .K(KA),
        .CLK(CLK),
        .RESET(RESET),
        .Q(S[2])
    );

    jkff jk1 (
        .J(JB),
        .K(KB),
        .CLK(CLK),
        .RESET(RESET),
        .Q(S[1])
    );

    jkff jk0 (
        .J(JC),
        .K(KC),
        .CLK(CLK),
        .RESET(RESET),
        .Q(S[0])
    );

endmodule
