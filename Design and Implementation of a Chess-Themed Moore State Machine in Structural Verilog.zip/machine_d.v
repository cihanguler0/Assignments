module machine_d(
    input wire x,
    input wire CLK,
    input wire RESET,
    output wire F,
    output wire [2:0] S
);
    wire DA, DB, DC;
    wire A, B, C;

    assign A = S[2];
    assign B = S[1];
    assign C = S[0];

    assign DA = (A & ~B & ~C) | (x & ~A & ~B & C) | (x & A & ~B & C) | (~x & ~A & B & C);
    assign DB = (~A & B & C) | (x & ~A & ~C) | (~x & A & ~B & ~C);
    assign DC = (~A & ~C) | (x & A & ~B & ~C);

    assign F = A & B & ~C;

    dff dff2 (
        .D(DA),
        .CLK(CLK),
        .RESET(RESET),
        .Q(S[2])
    );

    dff dff1 (
        .D(DB),
        .CLK(CLK),
        .RESET(RESET),
        .Q(S[1])
    );

    dff dff0 (
        .D(DC),
        .CLK(CLK),
        .RESET(RESET),
        .Q(S[0])
    );

endmodule